package com.example.farmkita.models

data class SeedTip(
    val name: String,
    val iconResId: Int,
    val category: String,
    val guide: String
) 