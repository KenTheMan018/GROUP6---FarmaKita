package com.example.farmkita

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivityFarmingSeedCardBinding

class KalabasaGuideActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFarmingSeedCardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFarmingSeedCardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = "🎃 Kalabasa Growing Guide"
        val iconResId = R.drawable.ic_kalabasa // Ensure this drawable exists in res/drawable
        val guide = """
🎃 How to Take Care of Kalabasa (Squash) from Planting to Harvest

Kalabasa, also known as squash or Cucurbita maxima, is a nutritious and versatile vegetable commonly grown in the Philippines. It thrives in warm climates and is easy to grow with the right care. Here’s a step-by-step guide to help you from planting to harvesting.

🌱 1. Planning and Preparation  
✅ Tips:  
• Choose a sunny location — kalabasa grows best with 6–8 hours of sunlight daily.  
• Use well-drained, fertile soil rich in organic matter.  
• Prepare mounds or raised beds to improve drainage and root development.  
• Space plants well — they need plenty of room to spread (at least 1–2 meters between mounds).  

🚨 Reminders:  
• Avoid planting in areas prone to waterlogging — kalabasa roots can rot easily in wet soil.  
• Rotate crops each season to avoid soil-borne pests and diseases.  

🌾 2. Sowing the Seeds  
✅ Tips:  
• Direct seed into the soil — plant 2–3 seeds per mound about 1 inch deep.  
• Space mounds 1.5–2 meters apart to allow vines to sprawl.  
• Thin to the healthiest one or two seedlings once they grow 3–4 true leaves.  

🚨 Reminders:  
• Plant at the start of the dry season or when there’s plenty of sun and warmth.  
• Keep the soil evenly moist during germination (usually 5–10 days).  

🌿 3. Vine Growth and Maintenance  
✅ Tips:  
• Train vines to grow in one direction for easier management.  
• Use trellises or bamboo supports if space is limited.  
• Mulch around the base to retain moisture and reduce weeds.  
• Remove damaged or overcrowded leaves to promote airflow.  

🚨 Reminders:  
• Kalabasa vines can become very large — plan your space ahead of time.  
• Avoid stepping on vines — damaged stems can affect fruit development.  

💧 4. Watering and Fertilizing  
✅ Tips:  
• Water deeply 2–3 times per week, especially during flowering and fruit development.  
• Apply organic compost or animal manure before planting and side-dress with fertilizer during growth.  
• Use a balanced fertilizer (e.g., 14-14-14) or high-potassium mix when flowering starts.  

🚨 Reminders:  
• Don’t overwater — wet leaves can attract fungus. Water at the base of the plant in the early morning.  
• Avoid using too much nitrogen — it can result in lots of leaves but few fruits.  

🌸 5. Flowering and Pollination  
✅ Tips:  
• Kalabasa produces male and female flowers — female flowers have a small fruit at the base.  
• Encourage pollinators like bees or manually pollinate by transferring pollen from male to female flowers.  
• Flowering usually starts 30–45 days after planting.  

🚨 Reminders:  
• Lack of pollination leads to fruit drop or undeveloped squash.  
• Avoid spraying pesticides during flowering — it can harm pollinators.  

🎃 6. Harvesting Kalabasa  
✅ Tips:  
• Kalabasa is usually ready for harvest 90–120 days after planting.  
• Harvest when the fruit is fully mature, firm, and the skin is hard.  
• Use a sharp knife or pruning shears to cut the fruit with a short stem attached.  

🚨 Reminders:  
• Handle squash carefully — bruising can reduce storage life.  
• Don’t harvest too early — immature fruits don’t store well and may not taste good.  

🧊 7. Storing Kalabasa  
✅ Tips:  
• Store in a cool, dry place with good airflow.  
• Well-cured squash can last 2–3 months or more if stored properly.  
• You can also cut and freeze squash for longer-term use.  

🚨 Reminders:  
• Do not wash squash before storing — only wash before cooking.  
• Check stored squash regularly for signs of rot or mold.  

📌 Additional Tips and Reminders  
✅ Tips:  
• Intercrop kalabasa with corn or beans for space-saving and natural pest control.  
• Remove small or excess fruits early to help the plant focus energy on fewer, better-sized squash.  
• Use organic pest controls like neem spray or garlic chili solution.  

🚨 Reminders:  
• Watch for pests like squash beetles, aphids, and fruit borers.  
• Keep the area around the plant clean and dry to reduce disease risk.
""".trimIndent()

        // Apply values to UI
        binding.seedIcon.setImageResource(iconResId)
        binding.seedName.text = name
        binding.seedGuide.text = guide
        binding.toolbar.title = name
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }
}
