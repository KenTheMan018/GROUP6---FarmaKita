package com.example.farmkita.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.databinding.ItemCropPriceCardBinding
import com.example.farmkita.models.CropPrice

class CropPriceAdapter : ListAdapter<CropPrice, CropPriceAdapter.CropPriceViewHolder>(CropPriceDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CropPriceViewHolder {
        val binding = ItemCropPriceCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CropPriceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CropPriceViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class CropPriceViewHolder(
        private val binding: ItemCropPriceCardBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(cropPrice: CropPrice) {
            binding.apply {
                cropNameText.text = cropPrice.cropName
                categoryChip.text = cropPrice.category
                priceRangeText.text = cropPrice.priceRange
            }
        }
    }

    private class CropPriceDiffCallback : DiffUtil.ItemCallback<CropPrice>() {
        override fun areItemsTheSame(oldItem: CropPrice, newItem: CropPrice): Boolean {
            return oldItem.cropName == newItem.cropName
        }

        override fun areContentsTheSame(oldItem: CropPrice, newItem: CropPrice): Boolean {
            return oldItem == newItem
        }
    }
} 