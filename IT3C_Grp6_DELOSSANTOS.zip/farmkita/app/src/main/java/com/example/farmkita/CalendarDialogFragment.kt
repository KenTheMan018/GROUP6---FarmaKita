package com.example.farmkita

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.datepicker.MaterialDatePicker

class CalendarDialogFragment : Fragment() {
    interface OnDateSelectedListener {
        fun onDateSelected(date: Long)
    }

    var listener: OnDateSelectedListener? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val datePicker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("Select Date")
            .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
            .build()

        datePicker.addOnPositiveButtonClickListener { selection ->
            listener?.onDateSelected(selection)
            parentFragmentManager.beginTransaction().remove(this@CalendarDialogFragment).commit()
        }
        datePicker.addOnNegativeButtonClickListener {
            parentFragmentManager.beginTransaction().remove(this@CalendarDialogFragment).commit()
        }
        datePicker.addOnCancelListener {
            parentFragmentManager.beginTransaction().remove(this@CalendarDialogFragment).commit()
        }

        datePicker.show(parentFragmentManager, "material_date_picker")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Return an empty view
        return View(requireContext())
    }
}
