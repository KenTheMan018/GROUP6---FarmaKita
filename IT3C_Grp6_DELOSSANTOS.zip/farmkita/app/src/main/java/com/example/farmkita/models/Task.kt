package com.example.farmkita.models

import java.time.LocalDate

data class Task(
    val title: String,
    val time: String,
    var isDone: Boolean,
    val date: LocalDate
)
