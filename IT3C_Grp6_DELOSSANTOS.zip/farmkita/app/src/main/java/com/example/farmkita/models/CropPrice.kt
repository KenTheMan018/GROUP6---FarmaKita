package com.example.farmkita.models

data class CropPrice(
    val cropName: String,
    val category: String,
    val priceRange: String
) {
    companion object {
        fun fromDAPrice(daPrice: DAPrice): CropPrice {
            return CropPrice(
                cropName = daPrice.cropName,
                category = daPrice.category,
                priceRange = "₱${String.format("%,.2f", daPrice.minPrice)} - ₱${String.format("%,.2f", daPrice.maxPrice)}"
            )
        }

        fun fromPSAPrice(psaPrice: PSAPrice): CropPrice {
            return CropPrice(
                cropName = psaPrice.cropName,
                category = psaPrice.category,
                priceRange = "₱${String.format("%,.2f", psaPrice.minPrice)} - ₱${String.format("%,.2f", psaPrice.maxPrice)}"
            )
        }
    }
}

// Extension functions to convert API models to CropPrice
fun DAPrice.toCropPrice(): CropPrice {
    return CropPrice(
        cropName = this.cropName,
        category = this.category,
        priceRange = "₱${String.format("%,.2f", this.minPrice)} - ₱${String.format("%,.2f", this.maxPrice)}"
    )
}

fun PSAPrice.toCropPrice(): CropPrice {
    return CropPrice(
        cropName = this.cropName,
        category = this.category,
        priceRange = "₱${String.format("%,.2f", this.minPrice)} - ₱${String.format("%,.2f", this.maxPrice)}"
    )
}

// DA API Response Models
data class DAPrice(
    val cropName: String,
    val category: String,
    val minPrice: Double,
    val maxPrice: Double
)

// PSA API Response Models
data class PSAPrice(
    val cropName: String,
    val category: String,
    val minPrice: Double,
    val maxPrice: Double
) 