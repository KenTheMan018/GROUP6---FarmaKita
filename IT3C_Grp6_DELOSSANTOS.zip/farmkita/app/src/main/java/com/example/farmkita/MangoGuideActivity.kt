package com.example.farmkita

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivityFarmingSeedCardBinding

class MangoGuideActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFarmingSeedCardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFarmingSeedCardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = "🥭 Mango Growing Guide"
        val iconResId = R.drawable.ic_mango // make sure you have ic_mango in drawable
        val guide = """
🥭 How to Take Care of Mango Trees from Planting to Harvest

Mango trees are tropical fruit trees that can live for decades and produce sweet, juicy fruit if given the right care. While they take a few years to bear fruit, proper planting, watering, and pruning can ensure healthy growth and abundant harvests.

🌱 1. Planning and Preparation  
✅ Tips:  
• Choose a grafted mango variety suited for your region (e.g., Carabao, Alphonso, Kent).  
• Pick a sunny location with well-drained soil — mangoes need full sun for flowering and fruiting.  
• Test the soil pH — ideal is between 5.5 and 7.5.  

🚨 Reminders:  
• Avoid low-lying or flood-prone areas — mango trees dislike standing water.  
• Allow at least 5–10 meters of space from other trees or structures.  

🌾 2. Planting the Mango Tree  
✅ Tips:  
• Dig a hole twice as wide and deep as the root ball.  
• Mix compost into the soil.  
• Keep the graft union above soil level.  
• Water thoroughly after planting.  

🚨 Reminders:  
• Do not bury the graft union.  
• Water regularly for the first few months.  

🌿 3. Early Growth and Tree Care  
✅ Tips:  
• Water during dry seasons for the first 1–2 years.  
• Mulch to retain moisture and prevent weeds.  
• Use balanced fertilizer (14-14-14) every 3–4 months.  
• Prune lightly to shape the tree.  

🚨 Reminders:  
• Don’t overwater.  
• Keep fertilizer away from the trunk.  

🌸 4. Flowering and Fruit Development  
✅ Tips:  
• Trees flower after 3–5 years, typically in the dry season.  
• Reduce watering during flowering.  
• Resume watering when fruits develop.  
• Support heavy branches.  

🚨 Reminders:  
• Don’t shake or prune during flowering.  
• Watch out for fruit flies and mango hoppers.  

💧 5. Watering and Fertilizing (Mature Trees)  
✅ Tips:  
• Water deeply during long dry spells.  
• Use potassium-rich fertilizer (0-0-50) during fruiting.  
• Mulch to retain moisture.  

🚨 Reminders:  
• Stop fertilizing 1–2 months before harvest.  
• Water after applying fertilizer.  

🥭 6. Harvesting the Mangoes  
✅ Tips:  
• Mangoes mature 3–5 months after flowering.  
• Harvest when fruits turn color and soften.  
• Use shears to cut with a short stem.  

🚨 Reminders:  
• Don’t pull mangoes off the tree.  
• Mango sap can irritate skin — handle with care.  

🧊 7. Post-Harvest Handling and Storage  
✅ Tips:  
• Let ripen at room temperature.  
• Store ripe mangoes in the fridge for 5–7 days.  
• Handle gently to prevent bruises.  

🚨 Reminders:  
• Do not wash before storing.  
• Keep away from bananas or other ethylene-sensitive fruits.  

📌 Additional Tips and Reminders  
✅ Tips:  
• Prune annually after harvest.  
• Use neem oil or sticky traps for pests.  
• Intercrop with legumes to improve soil.  

🚨 Reminders:  
• Avoid spraying chemicals during fruiting.  
• Watch for fungi, borers, and scale insects.  
""".trimIndent()

        // Apply values to UI
        binding.seedIcon.setImageResource(iconResId)
        binding.seedName.text = name
        binding.seedGuide.text = guide
        binding.toolbar.title = name
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }
}
