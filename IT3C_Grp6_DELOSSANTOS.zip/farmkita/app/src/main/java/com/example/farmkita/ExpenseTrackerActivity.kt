package com.example.farmkita

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.farmkita.databinding.ActivityExpenseTrackerBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import android.graphics.pdf.PdfDocument
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

class ExpenseTrackerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityExpenseTrackerBinding
    private val numberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    private val expenses = mutableListOf<Expense>()
    private lateinit var adapter: ExpenseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseTrackerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        updateTotalExpenses()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Expense Tracker"
        }
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupRecyclerView() {
        adapter = ExpenseAdapter(expenses) { expense ->
            showExpenseDetails(expense)
        }
        binding.expensesRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@ExpenseTrackerActivity)
            adapter = this@ExpenseTrackerActivity.adapter
        }
    }

    private fun setupClickListeners() {
        binding.addExpenseButton.setOnClickListener {
            showAddExpenseDialog()
        }

        binding.exportButton.setOnClickListener {
            showExportOptionsDialog()
        }
    }

    private fun updateTotalExpenses() {
        val total = expenses.sumOf { it.amount }
        binding.totalExpensesValue.text = "₱" + String.format("%,.2f", total)
        binding.expenseCountValue.text = expenses.size.toString()
    }

    private fun showAddExpenseDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_expense, null)
        val titleEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.titleEditText)
        val amountEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.amountEditText)
        val descriptionEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.descriptionEditText)

        MaterialAlertDialogBuilder(this)
            .setTitle("Add New Expense")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val title = titleEditText.text.toString().trim()
                val amountText = amountEditText.text.toString().trim()
                val description = descriptionEditText.text.toString().trim()

                if (title.isEmpty()) {
                    Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (amountText.isEmpty()) {
                    Toast.makeText(this, "Please enter an amount", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val amount = try {
                    amountText.replace("₱", "").replace(",", "").toDouble()
                } catch (e: NumberFormatException) {
                    Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val newExpense = Expense(
                    title,
                    "Other", // Default category since we removed it from the dialog
                    amount,
                    SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                    description.ifEmpty { "No description" }
                )
                
                expenses.add(newExpense)
                adapter.notifyItemInserted(expenses.size - 1)
                updateTotalExpenses()
                Toast.makeText(this, "Expense added successfully", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExpenseDetails(expense: Expense) {
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(expense.title)
            .setMessage("""
                Amount: ₱${String.format("%,.2f", expense.amount)}
                Date: ${expense.date}
                Description: ${expense.description}
            """.trimIndent())
            .setPositiveButton("Edit", null)
            .setNegativeButton("Delete") { _, _ ->
                expenses.remove(expense)
                adapter.notifyDataSetChanged()
                updateTotalExpenses()
                Toast.makeText(this, "Expense deleted", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Close", null)
            .create()

        dialog.setOnShowListener {
            val editButton = dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE)
            editButton.setOnClickListener {
                dialog.dismiss()
                showEditExpenseDialog(expense)
            }
        }
        dialog.show()
    }

    private fun showEditExpenseDialog(expense: Expense) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_expense, null)
        val titleEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.titleEditText)
        val amountEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.amountEditText)
        val descriptionEditText = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.descriptionEditText)

        // Pre-fill the fields with current expense data
        titleEditText.setText(expense.title)
        amountEditText.setText(expense.amount.toString())
        descriptionEditText.setText(expense.description)

        val editDialog = MaterialAlertDialogBuilder(this)
            .setTitle("Edit Expense")
            .setView(dialogView)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()

        editDialog.setOnShowListener {
            val saveButton = editDialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE)
            saveButton.setOnClickListener {
                val title = titleEditText.text.toString().trim()
                val amountText = amountEditText.text.toString().trim()
                val description = descriptionEditText.text.toString().trim()

                if (title.isEmpty()) {
                    Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (amountText.isEmpty()) {
                    Toast.makeText(this, "Please enter an amount", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val amount = try {
                    amountText.replace("₱", "").replace(",", "").toDouble()
                } catch (e: NumberFormatException) {
                    Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                // Update the expense
                expense.title = title
                expense.amount = amount
                expense.description = description.ifEmpty { "No description" }
                
                adapter.notifyDataSetChanged()
                updateTotalExpenses()
                Toast.makeText(this, "Expense updated successfully", Toast.LENGTH_SHORT).show()
                editDialog.dismiss()
            }
        }
        editDialog.show()
    }

    private fun showExportOptionsDialog() {
        val options = arrayOf("PDF Report", "Excel (XLSX)", "Word Document (DOCX)")
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Export Expense Report")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> exportToPDF()
                    1 -> exportToExcel()
                    2 -> exportToWord()
                }
            }
            .show()
    }

    private fun exportToPDF() {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var y = 40
            val paint = android.graphics.Paint()
            paint.textSize = 16f
            paint.isFakeBoldText = true
            canvas.drawText("Expense Report", 40f, y.toFloat(), paint)
            y += 40
            paint.textSize = 12f
            paint.isFakeBoldText = false

            // Table header
            canvas.drawText("Title", 40f, y.toFloat(), paint)
            canvas.drawText("Category", 200f, y.toFloat(), paint)
            canvas.drawText("Amount", 350f, y.toFloat(), paint)
            canvas.drawText("Date", 450f, y.toFloat(), paint)
            y += 20

            // Table rows
            for (expense in expenses) {
                canvas.drawText(expense.title, 40f, y.toFloat(), paint)
                canvas.drawText(expense.category, 200f, y.toFloat(), paint)
                canvas.drawText("₱${String.format("%,.2f", expense.amount)}", 350f, y.toFloat(), paint)
                canvas.drawText(expense.date, 450f, y.toFloat(), paint)
                y += 20
            }

            pdfDocument.finishPage(page)

            val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "expense_report.pdf")
            pdfDocument.writeTo(FileOutputStream(file))
            pdfDocument.close()
            Toast.makeText(this, "PDF exported to: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to export PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportToExcel() {
        try {
            val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "expense_report.csv")
            file.printWriter().use { out ->
                out.println("Title,Category,Amount,Date")
                for (expense in expenses) {
                    out.println("\"${expense.title}\",\"${expense.category}\",\"${expense.amount}\",\"${expense.date}\"")
                }
            }
            Toast.makeText(this, "CSV exported to: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to export CSV: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportToWord() {
        try {
            val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "expense_report.doc")
            file.printWriter().use { out ->
                out.println("Expense Report\n")
                out.println("Title\tCategory\tAmount\tDate")
                for (expense in expenses) {
                    out.println("${expense.title}\t${expense.category}\t₱${String.format("%,.2f", expense.amount)}\t${expense.date}")
                }
            }
            Toast.makeText(this, "Word document exported to: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to export Word document: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}

data class Expense(
    var title: String,
    val category: String,
    var amount: Double,
    val date: String,
    var description: String
) 