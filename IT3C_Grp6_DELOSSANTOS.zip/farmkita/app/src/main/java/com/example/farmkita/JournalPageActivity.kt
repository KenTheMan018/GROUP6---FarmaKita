package com.example.farmkita

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import com.example.farmkita.adapters.JournalAdapter
import com.example.farmkita.models.JournalEntry
import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import android.view.View
import android.widget.TextView

class JournalPageActivity : AppCompatActivity() {

    private lateinit var journalRecyclerView: RecyclerView
    private lateinit var journalAdapter: JournalAdapter
    private lateinit var journalList: MutableList<JournalEntry>

    private val editNoteLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            if (data != null) {
                val title = data.getStringExtra("title") ?: ""
                val note = data.getStringExtra("note") ?: ""
                val dateTime = data.getStringExtra("dateTime") ?: ""
                val position = data.getIntExtra("position", -1)
                if (position != -1) {
                    // Edit existing entry
                    journalList[position] = JournalEntry(title, note, dateTime)
                    journalAdapter.updateList(journalList)
                    updateEmptyView(journalList)
                }
            }
        }
    }

    private val addNoteLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            if (data != null) {
                val title = data.getStringExtra("title") ?: ""
                val note = data.getStringExtra("note") ?: ""
                val dateTime = data.getStringExtra("dateTime") ?: ""
                val position = data.getIntExtra("position", -1)
                if (position == -1) {
                    // Add new entry
                    val newEntry = JournalEntry(title, note, dateTime)
                    journalList.add(0, newEntry) // Add at top
                    journalAdapter.updateList(journalList)
                    updateEmptyView(journalList)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_journal_page)

        // Setup toolbar and FAB
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Farm Journal"
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        val fabAddNote = findViewById<FloatingActionButton>(R.id.fabAddNote)
        fabAddNote.setOnClickListener {
            addNoteLauncher.launch(Intent(this, FarmJournalActivity::class.java))
        }

        // Setup RecyclerView
        journalRecyclerView = findViewById(R.id.journalRecyclerView)
        journalRecyclerView.layoutManager = LinearLayoutManager(this)

        journalList = mutableListOf()

        journalAdapter = JournalAdapter(journalList) { entry, position ->
            val intent = Intent(this, FarmJournalActivity::class.java)
            intent.putExtra("title", entry.title)
            intent.putExtra("note", entry.note)
            intent.putExtra("dateTime", entry.dateTime)
            intent.putExtra("position", position)
            editNoteLauncher.launch(intent)
        }
        journalRecyclerView.adapter = journalAdapter
        updateEmptyView(journalList)

        // Search
        val searchEditText = findViewById<TextInputEditText>(R.id.searchEditText)
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().trim().lowercase()
                val filteredList = journalList.filter {
                    it.title.lowercase().contains(query)
                }
                journalAdapter.updateList(filteredList)
                updateEmptyView(filteredList)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun updateEmptyView(list: List<JournalEntry>) {
        val emptyNotesText = findViewById<TextView>(R.id.emptyNotesText)
        emptyNotesText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }
}
