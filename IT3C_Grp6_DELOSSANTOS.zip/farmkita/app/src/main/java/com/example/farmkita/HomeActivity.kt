package com.example.farmkita

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.farmkita.CropCalculationActivity
import com.example.farmkita.databinding.ActivityHomeBinding
import com.example.farmkita.fragments.FragmentSalesPerformance
import com.example.farmkita.fragments.HomeFragment
import com.example.farmkita.fragments.MarketFragment
import com.example.farmkita.fragments.ProfileFragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private lateinit var auth: FirebaseAuth
    private var currentUser: FirebaseUser? = null
    private lateinit var sharedPreferences: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firebase Auth
        auth = Firebase.auth
        currentUser = auth.currentUser
        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)

        // Check if user is logged in
        if (currentUser == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setupToolbar()
        setupBottomNavigation()
        updateThemeIcon()
        
        // Set up FAB to launch CropCalculationActivity
        binding.fabCalculator.setOnClickListener {
            val intent = Intent(this, CropCalculationActivity::class.java)
            startActivity(intent)
        }
        // Load home fragment by default
        loadFragment(HomeFragment())
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    loadFragment(HomeFragment())
                    true
                }
                R.id.navigation_market -> {
                    loadFragment(MarketFragment())
                    true
                }
                R.id.navigation_calculator -> {
                    showCropCalculatorDialog()
                    true
                }
                R.id.navigation_analytics -> {
                    loadFragment(FragmentSalesPerformance())
                    true
                }
                R.id.navigation_profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }
    }

    private fun showCropCalculatorDialog() {
        val dialog = DashboardDialogFragment()
        dialog.show(supportFragmentManager, "DashboardDialog")
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.home_toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_theme_toggle -> {
                toggleTheme()
                true
            }
            R.id.action_settings_menu -> {
                showSettingsDropdown()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun toggleTheme() {
        val currentTheme = sharedPreferences.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        val newTheme = when (currentTheme) {
            AppCompatDelegate.MODE_NIGHT_NO -> AppCompatDelegate.MODE_NIGHT_YES
            AppCompatDelegate.MODE_NIGHT_YES -> AppCompatDelegate.MODE_NIGHT_NO
            else -> AppCompatDelegate.MODE_NIGHT_NO
        }
        AppCompatDelegate.setDefaultNightMode(newTheme)
        sharedPreferences.edit().putInt("theme_mode", newTheme).apply()
        updateThemeIcon()
    }

    private fun updateThemeIcon() {
        val isDarkMode = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        binding.toolbar.menu.findItem(R.id.action_theme_toggle)?.apply {
            setIcon(if (isDarkMode) R.drawable.ic_sun else R.drawable.ic_moon)
            icon?.setTint(ContextCompat.getColor(this@HomeActivity, 
                if (isDarkMode) android.R.color.white else android.R.color.black))
        }
    }

    private fun showSettingsDropdown() {
        val anchorView = binding.toolbar.findViewById<View>(R.id.action_settings_menu)
        val popup = PopupMenu(this, anchorView ?: binding.toolbar)
        val menu = popup.menu
        // Theme submenu
        val themeSubMenu = menu.addSubMenu("Theme")
        themeSubMenu.add(0, 1001, 0, "Light")
        themeSubMenu.add(0, 1002, 1, "Dark")
        themeSubMenu.add(0, 1003, 2, "System Default")
        // Other items
        menu.add(0, 1004, 3, "About")
        menu.add(0, 1005, 4, "Contact")
        menu.add(0, 1006, 5, "Logout")

        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                1001 -> { // Light
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    sharedPreferences.edit().putInt("theme_mode", AppCompatDelegate.MODE_NIGHT_NO).apply()
                    updateThemeIcon()
                    true
                }
                1002 -> { // Dark
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    sharedPreferences.edit().putInt("theme_mode", AppCompatDelegate.MODE_NIGHT_YES).apply()
                    updateThemeIcon()
                    true
                }
                1003 -> { // System Default
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                    sharedPreferences.edit().putInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM).apply()
                    updateThemeIcon()
                    true
                }
                1004 -> { // About
                    MaterialAlertDialogBuilder(this)
                        .setTitle("About FarmaKita")
                        .setMessage("FarmaKita is a comprehensive farming management application designed to help farmers optimize their agricultural operations.\n\nVersion: 1.0.0\n\nDeveloped with ❤️ for the farming community.")
                        .setPositiveButton("OK", null)
                        .show()
                    true
                }
                1005 -> { // Contact
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Contact Us")
                        .setMessage("For support or inquiries, email us at: support@farmakita.com")
                        .setPositiveButton("OK", null)
                        .show()
                    true
                }
                1006 -> { // Logout
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Logout")
                        .setMessage("Are you sure you want to logout?")
                        .setPositiveButton("Logout") { _, _ ->
                            auth.signOut()
                            startActivity(Intent(this, LoginActivity::class.java))
                            finish()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
} 