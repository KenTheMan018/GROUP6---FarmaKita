package com.example.farmkita

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.adapters.TaskAdapter
import com.example.farmkita.models.Task
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.kizitonwose.calendar.view.CalendarView
import com.kizitonwose.calendar.core.CalendarDay
import com.kizitonwose.calendar.core.DayPosition
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.time.Instant
import java.util.Locale
import java.time.YearMonth
import java.time.format.TextStyle
import com.kizitonwose.calendar.view.MonthDayBinder
import com.kizitonwose.calendar.view.ViewContainer
import com.google.android.material.textfield.TextInputEditText

fun Date.toLocalDate(): LocalDate = this.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()

class TaskReminderActivity : AppCompatActivity() {
    private lateinit var taskRecyclerView: RecyclerView
    private lateinit var fabAddTask: FloatingActionButton
    private lateinit var adapter: TaskAdapter
    private lateinit var calendarView: CalendarView
    private var selectedDate: LocalDate = LocalDate.now()
    private var filteredTasks = mutableListOf<Task>()
    private lateinit var monthYearTextView: TextView

    private val allTasks = mutableListOf<Task>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_reminder)

        taskRecyclerView = findViewById(R.id.taskRecyclerView)
        fabAddTask = findViewById(R.id.fabAddTask)
        calendarView = findViewById(R.id.calendarView)
        monthYearTextView = findViewById(R.id.monthYearTextView)

        adapter = TaskAdapter(mutableListOf()) { _, _ -> }
        taskRecyclerView.layoutManager = LinearLayoutManager(this)
        taskRecyclerView.adapter = adapter

        // Calendar setup
        val currentMonth = YearMonth.now()
        val startMonth = currentMonth.minusMonths(12)
        val endMonth = currentMonth.plusMonths(12)
        calendarView.setup(startMonth, endMonth, java.time.DayOfWeek.SUNDAY)
        calendarView.scrollToMonth(currentMonth)

        updateMonthYearHeader(currentMonth)
        calendarView.monthScrollListener = { month ->
            updateMonthYearHeader(month.yearMonth)
        }

        calendarView.dayBinder = object : MonthDayBinder<DayViewContainer> {
            override fun create(view: View) = DayViewContainer(view)
            override fun bind(container: DayViewContainer, day: CalendarDay) {
                container.day = day
                container.textView.text = day.date.dayOfMonth.toString()
                if (day.date == selectedDate) {
                    container.textView.setBackgroundResource(R.drawable.selected_day_background)
                } else {
                    container.textView.background = null
                }
                container.textView.isEnabled = !day.date.isBefore(LocalDate.now())
                container.textView.alpha = if (day.position == DayPosition.MonthDate && !day.date.isBefore(LocalDate.now())) 1f else 0.3f
                // Show dot if there is a task for this date
                val hasTask = allTasks.any { it.date == day.date }
                container.taskDot.visibility = if (hasTask) View.VISIBLE else View.GONE
            }
        }
        calendarView.dayViewResource = R.layout.calendar_day_layout

        filterTasksForSelectedDate()

        fabAddTask.setOnClickListener {
            // Show add task dialog for selectedDate
            showTaskDialogForDate(selectedDate)
        }
    }

    private fun filterTasksForSelectedDate() {
        filteredTasks.clear()
        filteredTasks.addAll(allTasks.filter { it.date == selectedDate })
        adapter.updateList(filteredTasks)
    }

    private fun showTaskDialog(task: Task? = null, position: Int? = null) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_task_input, null)
        val titleEditText = dialogView.findViewById<TextInputEditText>(R.id.taskTitleEditText)
        val timeEditText = dialogView.findViewById<TextInputEditText>(R.id.taskTimeEditText)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)
        val saveButton = dialogView.findViewById<Button>(R.id.saveButton)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        if (task != null) {
            titleEditText.setText(task.title)
            timeEditText.setText(task.time)
        }

        saveButton.setOnClickListener {
            val title = titleEditText.text.toString().trim()
            val time = timeEditText.text.toString().trim()

            if (title.isNotEmpty() && time.isNotEmpty()) {
                if (task == null) {
                    // Create new task for selected date
                    val newTask = Task(title, time, false, selectedDate)
                    allTasks.add(newTask)
                } else if (position != null && position in filteredTasks.indices) {
                    // Update existing task
                    val updatedTask = task.copy(title = title, time = time)
                    val indexInAll = allTasks.indexOfFirst { it === task }
                    if (indexInAll != -1) allTasks[indexInAll] = updatedTask
                    filteredTasks[position] = updatedTask
                }
                filterTasksForSelectedDate()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Please enter both task title and time.", Toast.LENGTH_SHORT).show()
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }

    private fun showTaskDialogForDate(date: LocalDate) {
        // Show add task dialog for the selected date
        showTaskDialog()
    }

    private fun updateMonthYearHeader(yearMonth: YearMonth) {
        val monthName = yearMonth.month.getDisplayName(TextStyle.FULL, Locale.getDefault())
        val year = yearMonth.year
        monthYearTextView.text = "$monthName $year"
    }

    inner class DayViewContainer(view: View) : ViewContainer(view) {
        val textView: TextView = view.findViewById(R.id.calendarDayText)
        val taskDot: View = view.findViewById(R.id.taskDot)
        var day: CalendarDay? = null
        init {
            view.setOnClickListener {
                val day = day
                if (day != null && day.position == DayPosition.MonthDate && !day.date.isBefore(LocalDate.now())) {
                    selectedDate = day.date
                    calendarView.notifyCalendarChanged()
                    filterTasksForSelectedDate()
                }
            }
        }
    }
}
