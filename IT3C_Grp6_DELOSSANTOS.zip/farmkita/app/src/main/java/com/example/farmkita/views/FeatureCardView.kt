package com.example.farmkita.views

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import com.example.farmkita.R
import com.example.farmkita.databinding.ViewFeatureCardBinding

class FeatureCardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private val binding: ViewFeatureCardBinding

    var title: String
        get() = binding.titleText.text.toString()
        set(value) {
            binding.titleText.text = value
        }

    var subtitle: String
        get() = binding.subtitleText.text.toString()
        set(value) {
            binding.subtitleText.text = value
        }

    var icon: Drawable?
        get() = binding.iconImage.drawable
        set(value) {
            binding.iconImage.setImageDrawable(value)
        }

    init {
        binding = ViewFeatureCardBinding.inflate(LayoutInflater.from(context), this)
    }

    fun setTitleTextColor(color: Int) {
        binding.titleText.setTextColor(color)
    }

    fun setSubtitleTextColor(color: Int) {
        binding.subtitleText.setTextColor(color)
    }
} 