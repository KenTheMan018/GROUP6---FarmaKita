package com.example.farmkita.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.R
import com.example.farmkita.models.SeedTip
import com.google.android.material.chip.Chip

class SeedTipAdapter(
    private val seeds: List<SeedTip>,
    private val onClick: (SeedTip) -> Unit
) : RecyclerView.Adapter<SeedTipAdapter.SeedTipViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeedTipViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_seed_card, parent, false)
        return SeedTipViewHolder(view)
    }

    override fun onBindViewHolder(holder: SeedTipViewHolder, position: Int) {
        holder.bind(seeds[position])
    }

    override fun getItemCount() = seeds.size

    inner class SeedTipViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val seedName: TextView = itemView.findViewById(R.id.seedName)
        private val categoryChip: Chip = itemView.findViewById(R.id.categoryChip)
        private val seedPreview: TextView = itemView.findViewById(R.id.seedPreview)

        fun bind(seed: SeedTip) {
            seedName.text = seed.name
            categoryChip.text = seed.category

            // Generate a preview from the first 100 characters
            val previewText = seed.guide.trim().take(100)
            seedPreview.text = previewText

            itemView.setOnClickListener { onClick(seed) }
        }
    }
}
