package com.example.farmkita

import androidx.lifecycle.LiveData
import com.example.farmkita.InventoryDao
import com.example.farmkita.models.InventoryItem

class InventoryRepository(private val inventoryDao: InventoryDao) {

    val allItems: LiveData<List<InventoryItem>> = inventoryDao.getAllItems()

    suspend fun insert(item: InventoryItem) {
        inventoryDao.insert(item)
    }

    suspend fun update(item: InventoryItem) {
        inventoryDao.update(item)
    }

    suspend fun delete(item: InventoryItem) {
        inventoryDao.delete(item)
    }

    suspend fun clearAll() {
        inventoryDao.clearAll()
    }
}
