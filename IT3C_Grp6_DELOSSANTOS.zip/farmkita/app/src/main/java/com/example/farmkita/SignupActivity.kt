package com.example.farmkita

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.view.Window
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivitySignUpBinding
import com.example.farmkita.databinding.DialogTermsConditionsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding
    private lateinit var auth: FirebaseAuth
    private val database = Firebase.database.reference
    private var termsAccepted = false

    companion object {
        private const val TAG = "SignUpActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivitySignUpBinding.inflate(layoutInflater)
            setContentView(binding.root)
            auth = Firebase.auth

            // If user is already logged in, redirect to Home
            if (auth.currentUser != null) {
                navigateToHome()
                return
            }

            setupToolbar()
            setupTermsAndConditions()
            setupClickListeners()
        } catch (e: Exception) {
            Log.e(TAG, "Error in onCreate: ${e.message}", e)
            Toast.makeText(this, "Error initializing sign up: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun setupToolbar() {
        try {
            setSupportActionBar(binding.toolbar)
            supportActionBar?.apply {
                setDisplayHomeAsUpEnabled(true)
                setDisplayShowHomeEnabled(true)
                setDisplayShowTitleEnabled(false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up toolbar: ${e.message}", e)
        }
    }

    private fun setupTermsAndConditions() {
        try {
            val termsText = "I agree to the Terms and Conditions"
            val spannableString = SpannableString(termsText)
            val clickableSpan = object : ClickableSpan() {
                override fun onClick(widget: View) {
                    showTermsAndConditionsDialog()
                }

                override fun updateDrawState(ds: TextPaint) {
                    super.updateDrawState(ds)
                    ds.isUnderlineText = true
                    ds.color = getColor(R.color.farmakita_green)
                }
            }
            spannableString.setSpan(clickableSpan, 10, termsText.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            binding.termsCheckBox.text = spannableString
            binding.termsCheckBox.movementMethod = LinkMovementMethod.getInstance()
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up terms: ${e.message}", e)
        }
    }

    private fun showTermsAndConditionsDialog() {
        try {
            val dialog = Dialog(this)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            val dialogBinding = DialogTermsConditionsBinding.inflate(layoutInflater)
            dialog.setContentView(dialogBinding.root)
            
            dialog.window?.apply {
                setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                attributes = attributes.apply {
                    width = (resources.displayMetrics.widthPixels * 0.9).toInt()
                    height = (resources.displayMetrics.heightPixels * 0.8).toInt()
                }
            }

            dialog.setCancelable(false)
            dialog.setCanceledOnTouchOutside(false)

            dialogBinding.acceptButton.setOnClickListener {
                termsAccepted = true
                binding.termsCheckBox.isChecked = true
                dialog.dismiss()
                showAcceptanceConfirmation()
            }

            dialogBinding.declineButton.setOnClickListener {
                termsAccepted = false
                binding.termsCheckBox.isChecked = false
                dialog.dismiss()
            }

            dialog.show()
        } catch (e: Exception) {
            Log.e(TAG, "Error showing terms dialog: ${e.message}", e)
            Toast.makeText(this, "Error showing terms: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAcceptanceConfirmation() {
        try {
            MaterialAlertDialogBuilder(this)
                .setTitle("Terms Accepted")
                .setMessage("You have accepted the Terms and Conditions. You can now proceed with creating your account.")
                .setPositiveButton("OK", null)
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error showing acceptance confirmation: ${e.message}", e)
        }
    }

    private fun setupClickListeners() {
        try {
            binding.signUpButton.setOnClickListener {
                if (validateInputs()) {
                    signUp()
                }
            }

            binding.loginText.setOnClickListener {
                finish()
            }

            binding.termsCheckBox.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked && !termsAccepted) {
                    showTermsAndConditionsDialog()
                    binding.termsCheckBox.isChecked = false
                } else if (!isChecked) {
                    termsAccepted = false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up click listeners: ${e.message}", e)
        }
    }

    private fun validateInputs(): Boolean {
        try {
            var isValid = true

            with(binding) {
                // Validate first name
                if (firstNameEditText.text.toString().trim().isEmpty()) {
                    firstNameLayout.error = "Please enter your first name"
                    isValid = false
                } else {
                    firstNameLayout.error = null
                }

                // Validate last name
                if (lastNameEditText.text.toString().trim().isEmpty()) {
                    lastNameLayout.error = "Please enter your last name"
                    isValid = false
                } else {
                    lastNameLayout.error = null
                }

                // Validate email
                val email = emailEditText.text.toString().trim()
                if (email.isEmpty()) {
                    emailLayout.error = "Please enter your email"
                    isValid = false
                } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    emailLayout.error = "Please enter a valid email"
                    isValid = false
                } else {
                    emailLayout.error = null
                }

                // Validate password
                val password = passwordEditText.text.toString()
                if (password.isEmpty()) {
                    passwordLayout.error = "Please enter a password"
                    isValid = false
                } else if (password.length < 6) {
                    passwordLayout.error = "Password must be at least 6 characters"
                    isValid = false
                } else {
                    passwordLayout.error = null
                }

                // Validate confirm password
                val confirmPassword = confirmPasswordEditText.text.toString()
                if (confirmPassword.isEmpty()) {
                    confirmPasswordLayout.error = "Please confirm your password"
                    isValid = false
                } else if (confirmPassword != password) {
                    confirmPasswordLayout.error = "Passwords do not match"
                    isValid = false
                } else {
                    confirmPasswordLayout.error = null
                }

                // Validate terms and conditions
                if (!termsCheckBox.isChecked) {
                    showTermsNotAcceptedDialog()
                    isValid = false
                }
            }

            return isValid
        } catch (e: Exception) {
            Log.e(TAG, "Error validating inputs: ${e.message}", e)
            Toast.makeText(this, "Error validating inputs: ${e.message}", Toast.LENGTH_SHORT).show()
            return false
        }
    }

    private fun showTermsNotAcceptedDialog() {
        try {
            MaterialAlertDialogBuilder(this)
                .setTitle("Terms Required")
                .setMessage("You must accept the Terms and Conditions to create an account.")
                .setPositiveButton("View Terms") { _, _ ->
                    showTermsAndConditionsDialog()
                }
                .setNegativeButton("Cancel", null)
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error showing terms dialog: ${e.message}", e)
            Toast.makeText(this, "Please accept the Terms and Conditions", Toast.LENGTH_SHORT).show()
        }
    }

    private fun signUp() {
        try {
            binding.progressBar.visibility = View.VISIBLE
            binding.signUpButton.isEnabled = false

            val email = binding.emailEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString()
            val firstName = binding.firstNameEditText.text.toString().trim()
            val lastName = binding.lastNameEditText.text.toString().trim()
            val fullName = "$firstName $lastName"

            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    try {
                        binding.progressBar.visibility = View.GONE
                        binding.signUpButton.isEnabled = true

                        if (task.isSuccessful) {
                            // Update user profile with full name
                            val user = auth.currentUser
                            val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                                .setDisplayName(fullName)
                                .build()

                            user?.updateProfile(profileUpdates)
                                ?.addOnCompleteListener { profileTask ->
                                    if (profileTask.isSuccessful) {
                                        showSuccessDialog()
                                    } else {
                                        showErrorDialog("Failed to update profile: ${profileTask.exception?.message}")
                                    }
                                }
                        } else {
                            val errorMessage = when {
                                task.exception?.message?.contains("email address is already in use") == true ->
                                    "This email is already registered. Please use a different email or try logging in."
                                task.exception?.message?.contains("badly formatted") == true ->
                                    "Please enter a valid email address."
                                else -> "Sign up failed: ${task.exception?.message}"
                            }
                            showErrorDialog(errorMessage)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error in signup completion: ${e.message}", e)
                        showErrorDialog("An unexpected error occurred: ${e.message}")
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error in signup: ${e.message}", e)
            binding.progressBar.visibility = View.GONE
            binding.signUpButton.isEnabled = true
            showErrorDialog("An unexpected error occurred: ${e.message}")
        }
    }

    private fun showSuccessDialog() {
        try {
            MaterialAlertDialogBuilder(this)
                .setTitle("Success!")
                .setMessage("Your account has been created successfully. You can now log in.")
                .setPositiveButton("OK") { _, _ ->
                    finish()
                }
                .setCancelable(false)
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error showing success dialog: ${e.message}", e)
            finish()
        }
    }

    private fun showErrorDialog(message: String) {
        try {
            MaterialAlertDialogBuilder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error showing error dialog: ${e.message}", e)
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        startActivity(intent)
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
