package com.example.farmkita.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.farmkita.R
import com.example.farmkita.JournalPageActivity
import com.example.farmkita.adapters.CropPriceAdapter
import com.example.farmkita.databinding.FragmentMarketBinding
import com.example.farmkita.models.CropPrice
import com.google.android.material.chip.Chip

class MarketFragment : Fragment() {
    private var _binding: FragmentMarketBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: CropPriceAdapter
    private var currentFilter: String? = null

    // Sample data for demonstration
    private val cropPrices = listOf(
        CropPrice("Dry Palay", "Grains", "₱19 - ₱21"),
        CropPrice("Kangkong", "Vegetables", "₱12 - ₱15"),
        CropPrice("Native Pechay", "Vegetables", "₱18 - ₱21"),
        CropPrice("Ampalaya", "Vegetables", "₱24 - ₱28"),
        CropPrice("Chayote", "Vegetables", "₱14 - ₱16"),
        CropPrice("Squash", "Vegetables", "₱15 - ₱18"),
        CropPrice("Tomato", "Vegetables", "₱12 - ₱14"),
        CropPrice("Banana Saba", "Fruits", "₱10 - ₱12"),
        CropPrice("Banana Lakatan", "Fruits", "₱38 - ₱42"),
        CropPrice("Calamansi", "Fruits", "₱42 - ₱47")
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMarketBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        loadMarketPrices()
    }

    private fun setupUI() {
        setupRecyclerView()
        setupSearch()
        setupFilterChips()
        setupSwipeRefresh()
    }

    private fun setupRecyclerView() {
        adapter = CropPriceAdapter()
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@MarketFragment.adapter
        }
    }

    private fun setupSearch() {
        binding.searchEditText.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                filterPrices(query ?: "", currentFilter)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterPrices(newText ?: "", currentFilter)
                return true
            }
        })
    }

    private fun setupFilterChips() {
        // Clear existing chips
        binding.filterChipGroup.removeAllViews()

        // Add new chips
        val categories = listOf("All", "Vegetables", "Fruits", "Grains")
        categories.forEach { category ->
            val chip = Chip(requireContext()).apply {
                text = category
                isCheckable = true
                isChecked = category == "All"
                if (category == "All") {
                    currentFilter = null
                }
            }
            binding.filterChipGroup.addView(chip)
        }

        binding.filterChipGroup.setOnCheckedChangeListener { group, checkedId ->
            val chip = group.findViewById<Chip>(checkedId)
            currentFilter = if (chip?.text == "All") null else chip?.text?.toString()
            filterPrices(binding.searchEditText.query?.toString() ?: "", currentFilter)
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadMarketPrices()
        }
    }

    private fun loadMarketPrices() {
        showLoading(true)
        // For now, we're using sample data
        adapter.submitList(cropPrices)
        showLoading(false)
        binding.swipeRefresh.isRefreshing = false
        hideError()
    }

    private fun filterPrices(searchQuery: String, category: String?) {
        val filteredList = cropPrices.filter { price ->
            val matchesSearch = price.cropName.contains(searchQuery, ignoreCase = true) ||
                    price.category.contains(searchQuery, ignoreCase = true)
            val matchesCategory = category == null || price.category == category
            matchesSearch && matchesCategory
        }
        adapter.submitList(filteredList)
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (show) View.GONE else View.VISIBLE
    }

    private fun showError(message: String) {
        binding.errorContainer.visibility = View.VISIBLE
        binding.errorText.text = message
        binding.recyclerView.visibility = View.GONE
    }

    private fun hideError() {
        binding.errorContainer.visibility = View.GONE
        binding.recyclerView.visibility = View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}