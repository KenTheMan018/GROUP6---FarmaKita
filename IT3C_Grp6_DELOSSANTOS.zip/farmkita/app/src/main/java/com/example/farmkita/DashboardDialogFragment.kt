package com.example.farmkita

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.farmkita.models.CropCalculation
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

class DashboardDialogFragment : DialogFragment() {

    private lateinit var landAreaInput: TextInputEditText
    private lateinit var yieldInput: TextInputEditText
    private lateinit var priceInput: TextInputEditText
    private lateinit var costInput: TextInputEditText
    private lateinit var calculateButton: MaterialButton
    private lateinit var saveButton: MaterialButton

    private lateinit var totalYieldResult: android.widget.TextView
    private lateinit var grossRevenueResult: android.widget.TextView
    private lateinit var netProfitResult: android.widget.TextView
    private lateinit var roiResult: android.widget.TextView
    private lateinit var resultsContainer: View

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.setTitle("Crop Calculator")
        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.dialog_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize views
        landAreaInput = view.findViewById(R.id.landAreaInput)
        yieldInput = view.findViewById(R.id.yieldInput)
        priceInput = view.findViewById(R.id.priceInput)
        costInput = view.findViewById(R.id.costInput)
        calculateButton = view.findViewById(R.id.calculateButton)
        saveButton = view.findViewById(R.id.saveButton)

        totalYieldResult = view.findViewById(R.id.totalYieldResult)
        grossRevenueResult = view.findViewById(R.id.grossRevenueResult)
        netProfitResult = view.findViewById(R.id.netProfitResult)
        roiResult = view.findViewById(R.id.roiResult)
        resultsContainer = view.findViewById(R.id.resultsContainer)

        // Set up click listeners
        calculateButton.setOnClickListener {
            calculateResults()
        }

        saveButton.setOnClickListener {
            saveCalculation()
        }
    }

    private fun calculateResults() {
        try {
            val landArea = landAreaInput.text.toString().toDoubleOrNull() ?: 0.0
            val yield = yieldInput.text.toString().toDoubleOrNull() ?: 0.0
            val price = priceInput.text.toString().toDoubleOrNull() ?: 0.0
            val cost = costInput.text.toString().toDoubleOrNull() ?: 0.0

            if (landArea <= 0 || yield <= 0 || price <= 0) {
                Toast.makeText(context, "Please enter valid values", Toast.LENGTH_SHORT).show()
                return
            }

            val totalYield = landArea * yield
            val grossRevenue = totalYield * price
            val netProfit = grossRevenue - cost
            val roi = if (cost > 0) ((netProfit / cost) * 100) else 0.0

            val decimalFormat = DecimalFormat("#,##0.00")

            totalYieldResult.text = "${decimalFormat.format(totalYield)} kg"
            grossRevenueResult.text = "₱${decimalFormat.format(grossRevenue)}"
            netProfitResult.text = "₱${decimalFormat.format(netProfit)}"
            roiResult.text = "${decimalFormat.format(roi)}%"

            resultsContainer.visibility = View.VISIBLE

        } catch (e: Exception) {
            Toast.makeText(context, "Error in calculation", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveCalculation() {
        try {
            val landArea = landAreaInput.text.toString().toDoubleOrNull() ?: 0.0
            val yield = yieldInput.text.toString().toDoubleOrNull() ?: 0.0
            val price = priceInput.text.toString().toDoubleOrNull() ?: 0.0
            val cost = costInput.text.toString().toDoubleOrNull() ?: 0.0

            val totalYield = landArea * yield
            val grossRevenue = totalYield * price
            val netProfit = grossRevenue - cost
            val roi = if (cost > 0) ((netProfit / cost) * 100) else 0.0

            val calculation = CropCalculation(
                cropName = "Crop", // Default crop name
                landSize = landArea,
                seedCost = cost * 0.3, // Estimate 30% of total cost as seed cost
                fertilizerCost = cost * 0.4, // Estimate 40% of total cost as fertilizer cost
                laborCost = cost * 0.3, // Estimate 30% of total cost as labor cost
                sellingPricePerKg = price,
                expectedYieldPerHectare = yield
            )

            // Here you would typically save to database
            // For now, just show a success message
            Toast.makeText(context, "Calculation saved successfully!", Toast.LENGTH_SHORT).show()
            dismiss()

        } catch (e: Exception) {
            Toast.makeText(context, "Error saving calculation", Toast.LENGTH_SHORT).show()
        }
    }
} 