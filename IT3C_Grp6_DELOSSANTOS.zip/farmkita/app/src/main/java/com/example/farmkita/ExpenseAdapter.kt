package com.example.farmkita

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.databinding.ItemExpenseBinding
import java.text.NumberFormat
import java.util.*

class ExpenseAdapter(
    private val expenses: List<Expense>,
    private val onExpenseClick: (Expense) -> Unit
) : RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    private val numberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    inner class ExpenseViewHolder(private val binding: ItemExpenseBinding) : RecyclerView.ViewHolder(binding.root) {
        
        fun bind(expense: Expense) {
            binding.expenseTitle.text = expense.title
            binding.expenseCategory.text = expense.category
            binding.expenseAmount.text = "₱" + String.format("%,.2f", expense.amount)
            binding.expenseDate.text = expense.date
            
            binding.root.setOnClickListener {
                onExpenseClick(expense)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val binding = ItemExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ExpenseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        holder.bind(expenses[position])
    }

    override fun getItemCount(): Int = expenses.size
} 