package com.example.farmkita.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.farmkita.R
import com.example.farmkita.databinding.FragmentSalesPerformanceBinding
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import java.text.NumberFormat
import java.util.Locale

class FragmentSalesPerformance : Fragment() {
    private var _binding: FragmentSalesPerformanceBinding? = null
    private val binding get() = _binding!!
    private val numberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSalesPerformanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateDashboardMetrics()
        setupMonthlySalesChart()
    }

    private fun updateDashboardMetrics() {
        // Realistic data for ordinary Filipino farmers
        binding.totalSalesValue.text = "₱" + String.format("%,.2f", 180000.0)  // Total 6 months
        binding.averageOrderValue.text = "₱" + String.format("%,.2f", 1500.0)  // Average per order
        binding.totalOrdersValue.text = "120"  // Total orders in 6 months
        binding.growthRateValue.text = "+8.2%"  // Realistic growth rate
    }

    private fun setupMonthlySalesChart() {
        val chart = binding.monthlySalesChart
        val entries = listOf(
            Entry(0f, 25000f), // January
            Entry(1f, 28000f), // February
            Entry(2f, 32000f), // March
            Entry(3f, 27000f), // April
            Entry(4f, 35000f), // May
            Entry(5f, 43000f)  // June
        )
        val dataSet = LineDataSet(entries, "Monthly Sales")
        dataSet.color = ContextCompat.getColor(requireContext(), R.color.primary)
        dataSet.valueTextColor = ContextCompat.getColor(requireContext(), android.R.color.black)
        dataSet.lineWidth = 2f
        dataSet.circleRadius = 4f
        dataSet.setCircleColor(ContextCompat.getColor(requireContext(), R.color.primary))
        dataSet.setDrawFilled(true)
        dataSet.fillColor = ContextCompat.getColor(requireContext(), R.color.primary)
        dataSet.mode = LineDataSet.Mode.CUBIC_BEZIER

        val lineData = LineData(dataSet)
        chart.data = lineData
        chart.description.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.granularity = 1f
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.granularity = 1f
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(
            listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun")
        )
        chart.legend.isEnabled = false
        chart.setTouchEnabled(false)
        chart.invalidate()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}