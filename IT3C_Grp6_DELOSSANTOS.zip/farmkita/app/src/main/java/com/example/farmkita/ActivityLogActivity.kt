package com.example.farmkita

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.farmkita.adapters.ActivityLogAdapter
import com.example.farmkita.databinding.ActivityActivityLogBinding
import com.example.farmkita.models.ActivityLog
import com.example.farmkita.models.ActivityType
import com.google.android.material.chip.Chip
import java.text.SimpleDateFormat
import java.util.*

class ActivityLogActivity : AppCompatActivity() {
    private lateinit var binding: ActivityActivityLogBinding
    private lateinit var adapter: ActivityLogAdapter
    private var allLogs: MutableList<ActivityLog> = mutableListOf()
    private var filteredLogs: MutableList<ActivityLog> = mutableListOf()
    private var selectedType: ActivityType? = null
    private var startDate: Date? = null
    private var endDate: Date? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityActivityLogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ActivityLogAdapter()
        binding.rvActivityLog.layoutManager = LinearLayoutManager(this)
        binding.rvActivityLog.adapter = adapter

        // Load logs from SharedPreferences
        allLogs = loadLogsFromPrefs().toMutableList()
        filteredLogs = allLogs.toMutableList()
        adapter.submitList(filteredLogs)

        setupSearch()
        setupTypeFilter()
        setupClearButton()
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterLogs()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun setupTypeFilter() {
        binding.chipGroupType.setOnCheckedChangeListener { group, checkedId ->
            selectedType = when (checkedId) {
                R.id.chipTask -> ActivityType.TASK
                R.id.chipJournal -> ActivityType.JOURNAL
                R.id.chipExpense -> ActivityType.EXPENSE
                else -> null
            }
            filterLogs()
        }
    }

    private fun setupClearButton() {
        binding.btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear Logs")
                .setMessage("Are you sure you want to clear all logs?")
                .setPositiveButton("Yes") { _, _ ->
                    allLogs.clear()
                    // Also clear from SharedPreferences
                    getSharedPreferences("ActivityLogPrefs", MODE_PRIVATE).edit().clear().apply()
                    filterLogs()
                }
                .setNegativeButton("No", null)
                .show()
        }
    }

    private fun filterLogs() {
        val keyword = binding.etSearch.text?.toString() ?: ""
        filteredLogs = allLogs.filter { log ->
            (keyword.isBlank() || log.description.contains(keyword, ignoreCase = true)) &&
            (selectedType == null || log.type == selectedType) &&
            (startDate == null || !log.timestamp.before(startDate)) &&
            (endDate == null || !log.timestamp.after(endDate))
        }.toMutableList()
        adapter.submitList(filteredLogs)
    }

    private fun loadLogsFromPrefs(): List<ActivityLog> {
        val prefs = getSharedPreferences("ActivityLogPrefs", MODE_PRIVATE)
        val logs = prefs.getStringSet("logs", emptySet()) ?: emptySet()
        return logs.mapNotNull { entry ->
            val parts = entry.split("|", limit = 3)
            if (parts.size == 3) {
                val timestamp = Date(parts[0].toLongOrNull() ?: return@mapNotNull null)
                val type = when (parts[1]) {
                    "CALCULATION" -> ActivityType.TASK // Or create a new type if needed
                    "TASK" -> ActivityType.TASK
                    "JOURNAL" -> ActivityType.JOURNAL
                    "EXPENSE" -> ActivityType.EXPENSE
                    else -> ActivityType.TASK
                }
                ActivityLog(UUID.randomUUID().toString(), type, parts[2], timestamp)
            } else null
        }.sortedByDescending { it.timestamp }
    }

    private fun generateDummyLogs(): List<ActivityLog> {
        return emptyList()
    }
} 