package com.example.farmkita.models

import java.util.Date

/**
 * Represents a single activity log entry (task, expense, or journal).
 */
data class ActivityLog(
    val id: String = "",
    val type: ActivityType,
    val description: String,
    val timestamp: Date
)

enum class ActivityType {
    TASK, JOURNAL, EXPENSE
} 