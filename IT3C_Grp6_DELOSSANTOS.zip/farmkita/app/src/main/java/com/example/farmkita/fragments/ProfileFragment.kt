package com.example.farmkita.fragments

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.example.farmkita.EditProfileActivity
import com.example.farmkita.MainActivity
import com.example.farmkita.R
import com.example.farmkita.databinding.DialogAboutAppBinding
import com.example.farmkita.databinding.FragmentProfileBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask

class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth
    private val database = Firebase.database.reference

    // Activity result launcher for image selection
    private val getContent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val imageUri: Uri? = result.data?.data
            imageUri?.let {
                binding.profileImage.setImageURI(it)
                uploadProfileImageToFirebase(it)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = Firebase.auth
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupProfile()
        setupClickListeners()
    }

    override fun onResume() {
        super.onResume()
        // Refresh profile data when returning from EditProfileActivity
        setupProfile()
    }

    private fun setupProfile() {
        val user = auth.currentUser
        if (user == null) {
            if (context == null) return
            Toast.makeText(requireContext(), "User not authenticated.", Toast.LENGTH_SHORT).show()
            setDisplayNameFromAuthFallback()
            return
        }
        try {
            binding.tvEmail.text = user.email
            database.child("users").child(user.uid).get()
                .addOnSuccessListener { snapshot ->
                    if (!isAdded || context == null) return@addOnSuccessListener
                    try {
                        if (snapshot.exists()) {
                            val firstName = snapshot.child("firstName").value as? String
                            val lastName = snapshot.child("lastName").value as? String
                            val name = snapshot.child("name").value as? String

                            if (!firstName.isNullOrEmpty() && !lastName.isNullOrEmpty()) {
                                binding.tvFullName.text = "$firstName $lastName".capitalizeWords()
                            } else if (!name.isNullOrEmpty()) {
                                binding.tvFullName.text = name.capitalizeWords()
                            } else {
                                setDisplayNameFromAuth(user)
                            }

                            val imageUriStr = snapshot.child("profileImageUri").value as? String
                            if (!imageUriStr.isNullOrEmpty()) {
                                try {
                                    binding.profileImage.setImageURI(Uri.parse(imageUriStr))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    if (context != null) Toast.makeText(requireContext(), "Invalid profile image URI.", Toast.LENGTH_SHORT).show()
                                    binding.profileImage.setImageResource(R.drawable.default_profile)
                                }
                            } else {
                                binding.profileImage.setImageResource(R.drawable.default_profile)
                            }
                        } else {
                            setDisplayNameFromAuth(user)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        if (context != null) Toast.makeText(requireContext(), "Error loading profile data.", Toast.LENGTH_SHORT).show()
                        setDisplayNameFromAuth(user)
                    }
                }
                .addOnFailureListener { e ->
                    if (!isAdded || context == null) return@addOnFailureListener
                    e.printStackTrace()
                    Toast.makeText(requireContext(), "Failed to load profile from database.", Toast.LENGTH_SHORT).show()
                    setDisplayNameFromAuth(user)
                }
        } catch (e: Exception) {
            e.printStackTrace()
            if (context != null) Toast.makeText(requireContext(), "Unexpected error in profile setup.", Toast.LENGTH_SHORT).show()
            setDisplayNameFromAuthFallback()
        }
    }

    // Fallback for display name if user is null
    private fun setDisplayNameFromAuthFallback() {
        binding.tvFullName.text = "User"
        binding.tvEmail.text = ""
    }

    private fun setDisplayNameFromAuth(user: com.google.firebase.auth.FirebaseUser) {
        user.displayName?.let { displayName ->
            if (displayName.isNotEmpty()) {
                binding.tvFullName.text = displayName.capitalizeWords()
            } else {
                // If display name is empty, try to extract from email
                val emailName = user.email?.split("@")?.get(0)?.replace(".", " ")?.capitalizeWords()
                binding.tvFullName.text = emailName ?: "User"
            }
        } ?: run {
            // If display name is null, try to extract from email
            val emailName = user.email?.split("@")?.get(0)?.replace(".", " ")?.capitalizeWords()
            binding.tvFullName.text = emailName ?: "User"
        }
    }

    private fun setupClickListeners() {
        // Profile picture selection
        binding.cameraIcon.setOnClickListener {
            openImagePicker()
        }

        binding.profileImage.setOnClickListener {
            openImagePicker()
        }

        // Accordion menu items
        binding.editProfileItem.setOnClickListener {
            startActivity(Intent(requireContext(), EditProfileActivity::class.java))
        }

        binding.settingsItem.setOnClickListener {
            // Handle settings click - you can expand this to show settings options
            Toast.makeText(requireContext(), "Settings clicked", Toast.LENGTH_SHORT).show()
        }

        binding.aboutAppItem.setOnClickListener {
            showAboutDialog()
        }

        binding.logoutItem.setOnClickListener {
            showLogoutDialog()
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        getContent.launch(intent)
    }

    private fun showAboutDialog() {
        if (!isAdded || context == null) return
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("About FarmaKita")
            .setMessage("FarmaKita is a comprehensive farming management application designed to help farmers optimize their agricultural operations.\n\nKey Features:\n• Crop Management\n• Market Price Tracking\n• Sales Performance Analytics\n• Farm Planning Tools\n• Weather Integration\n• Financial Tracking\n\nOur Mission:\nTo empower farmers with modern technology solutions that enhance productivity, improve decision-making, and contribute to sustainable agriculture practices.\n\nVersion: 1.0.0\n\nDeveloped with ❤️ for the farming community")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showLogoutDialog() {
        if (!isAdded || context == null) return
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { _, _ ->
                auth.signOut()
                startActivity(Intent(requireContext(), MainActivity::class.java))
                requireActivity().finish()
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun String.capitalizeWords(): String {
        return this.split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { it.uppercase() }
        }
    }

    private fun uploadProfileImageToFirebase(imageUri: Uri) {
        val user = auth.currentUser ?: return
        val storageRef = FirebaseStorage.getInstance().reference
        val profileImagesRef = storageRef.child("profile_images/${user.uid}.jpg")

        val uploadTask = profileImagesRef.putFile(imageUri)
        uploadTask.addOnSuccessListener { _: UploadTask.TaskSnapshot ->
            if (!isAdded || context == null) return@addOnSuccessListener
            profileImagesRef.downloadUrl.addOnSuccessListener { uri: Uri ->
                if (!isAdded || context == null) return@addOnSuccessListener
                // Save the download URL to the database
                database.child("users").child(user.uid).child("profileImageUri").setValue(uri.toString())
                Toast.makeText(requireContext(), "Profile image updated!", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener { e: Exception ->
            if (!isAdded || context == null) return@addOnFailureListener
            e.printStackTrace()
            Toast.makeText(requireContext(), "Failed to upload profile image.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 