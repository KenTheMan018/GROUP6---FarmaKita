package com.example.farmkita

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.farmkita.InventoryDatabase
import com.example.farmkita.models.InventoryItem
import com.example.farmkita.InventoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InventoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: InventoryRepository
    val allInventoryItems: LiveData<List<InventoryItem>>

    init {
        val dao = InventoryDatabase.getDatabase(application).inventoryDao()
        repository = InventoryRepository(dao)
        allInventoryItems = repository.allItems
    }

    fun insertInventory(item: InventoryItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insert(item)
        }
    }

    fun updateInventory(item: InventoryItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.update(item)
        }
    }

    fun deleteInventory(item: InventoryItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(item)
        }
    }

    fun clearAllInventory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAll()
        }
    }
}
