package com.example.farmkita

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivityFarmingSeedCardBinding

class CarrotGuideActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFarmingSeedCardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFarmingSeedCardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = "🥕 Carrot Growing Guide"
        val iconResId = R.drawable.ic_carrot
        val guide = """
🥕 How to Take Care of Carrots from Seeds to Harvest

Growing carrots is a simple but rewarding process if you follow the right steps. Here’s a complete guide to help you care for your carrot plants, from planting the seeds all the way to harvesting and storing the roots.

🌱 1. Planning and Preparation  
✅ Tips:  
• Choose the right variety suited to your climate and soil conditions.  
• Select a sunny location that receives at least 6 hours of direct sunlight each day.  
• Prepare well-drained, loose soil — sandy or loamy is ideal.  
• Remove rocks and clumps from the soil to help roots grow straight and smooth.  

🚨 Reminders:  
• Avoid clay-heavy or compacted soil — it can cause carrots to grow twisted or stunted.  
• Carrots should be directly sown into the ground as they don’t transplant well.  

🌾 2. Sowing the Seeds  
✅ Tips:  
• Sow seeds ¼ inch (6 mm) deep, spaced 1–2 inches apart in shallow rows.  
• Thinly scatter seeds to avoid overcrowding.  
• Water gently after sowing to avoid displacing the seeds.  

🚨 Reminders:  
• Carrot seeds are slow to sprout — expect 1–3 weeks for germination.  
• Keep soil consistently moist, especially during the early stages.  

🌿 3. Thinning and Weeding  
✅ Tips:  
• When seedlings reach about 2 inches tall, thin them to 2 inches apart.  
• Keep the area weed-free to avoid competition for nutrients and water.  
• Use mulch to retain moisture and control weeds.  

🚨 Reminders:  
• Thin carefully — pull seedlings gently to avoid disturbing nearby roots.  
• Mulching also helps protect the developing roots from heat and sun.  

💧 4. Watering and Fertilizing  
✅ Tips:  
• Water deeply once a week (about 1 inch of water). This encourages deep root growth.  
• Use low-nitrogen fertilizer — too much nitrogen produces leafy tops, not healthy roots.  
• In hot weather, keep soil cool and evenly moist to prevent stress.  

🚨 Reminders:  
• Avoid soggy soil — overwatering can cause root rot.  
• If carrot tops turn green, cover exposed roots with soil or mulch to prevent bitterness.  

🥕 5. Harvesting the Carrots  
✅ Tips:  
• Carrots are typically ready to harvest 60–80 days after planting, depending on the variety.  
• Brush away soil to check the diameter — harvest when the root is about ¾ to 1 inch wide.  
• Loosen the soil before pulling to avoid snapping the roots.  

🚨 Reminders:  
• Don’t leave carrots in the ground too long — overripe roots become woody and bitter.  
• Harvest in the morning or evening to avoid wilting from sun exposure.  

🧊 6. Storing Carrots  
✅ Tips:  
• Cut off the green tops right after harvesting to preserve moisture.  
• Store in a cool, dark place, like a fridge or root cellar.  
• For long-term storage, keep carrots in damp sand or sawdust in a box.  

🚨 Reminders:  
• Do not wash carrots before storing — wait until you're ready to use them to prevent spoilage.  
• Monitor stored carrots regularly for signs of rot or mold.  

📌 Additional Tips and Reminders  
✅ Tips:  
• Rotate carrot crops each year to prevent soil-borne diseases.  
• Grow carrots near companion plants like onions, chives, or leeks — they help repel pests.  

🚨 Reminders:  
• Watch for pests like the carrot rust fly, whose larvae can tunnel into the roots.  
• Use row covers or natural pest deterrents to protect young plants.
""".trimIndent()

        binding.seedIcon.setImageResource(iconResId)
        binding.seedName.text = name
        binding.seedGuide.text = guide
        binding.toolbar.title = name
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }
}
