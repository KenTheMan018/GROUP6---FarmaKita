package com.example.farmkita

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.adapters.InventoryAdapter
import com.example.farmkita.models.InventoryItem
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText

class InventoryActivity : AppCompatActivity() {
    private lateinit var inventoryViewModel: InventoryViewModel
    private lateinit var inventoryAdapter: InventoryAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyText: TextView
    private lateinit var searchEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)

        // Initialize ViewModel
        inventoryViewModel = ViewModelProvider(this)[InventoryViewModel::class.java]

        // Initialize views
        recyclerView = findViewById(R.id.inventoryRecyclerView)
        emptyText = findViewById(R.id.emptyInventoryText)
        searchEditText = findViewById(R.id.searchInventoryEditText)
        val fabAddInventory = findViewById<FloatingActionButton>(R.id.fabAddInventory)

        // Setup RecyclerView
        setupRecyclerView()

        // Setup search functionality
        setupSearch()

        // Setup FAB click listener
        fabAddInventory.setOnClickListener {
            showAddInventoryDialog()
        }

        // Observe inventory items
        inventoryViewModel.allInventoryItems.observe(this) { items ->
            inventoryAdapter.submitList(items)
            updateEmptyState(items.isEmpty())
        }
    }

    private fun setupRecyclerView() {
        inventoryAdapter = InventoryAdapter(
            onEditClick = { item -> showEditInventoryDialog(item) },
            onDeleteClick = { item -> showDeleteConfirmationDialog(item) }
        )

        recyclerView.apply {
            layoutManager = LinearLayoutManager(this@InventoryActivity)
            adapter = inventoryAdapter
        }
    }

    private fun setupSearch() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterInventory(s.toString())
            }
        })
    }

    private fun filterInventory(query: String) {
        // This would need to be implemented in the ViewModel or adapter
        // For now, we'll just show all items
    }

    private fun updateEmptyState(isEmpty: Boolean) {
        emptyText.visibility = if (isEmpty) View.VISIBLE else View.GONE
        recyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun showAddInventoryDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_inventory_form, null)
        val nameEditText = dialogView.findViewById<TextInputEditText>(R.id.itemNameEditText)
        val categorySpinner = dialogView.findViewById<AutoCompleteTextView>(R.id.categorySpinner)
        val quantityEditText = dialogView.findViewById<TextInputEditText>(R.id.quantityEditText)
        val unitEditText = dialogView.findViewById<TextInputEditText>(R.id.unitEditText)
        val thresholdEditText = dialogView.findViewById<TextInputEditText>(R.id.thresholdEditText)
        val cancelButton = dialogView.findViewById<View>(R.id.cancelButton)
        val saveButton = dialogView.findViewById<View>(R.id.saveButton)

        // Setup category spinner
        val categories = arrayOf("Seeds", "Fertilizers", "Tools", "Equipment", "Other")
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categories)
        categorySpinner.setAdapter(categoryAdapter)
        categorySpinner.setOnClickListener { categorySpinner.showDropDown() }
        categorySpinner.keyListener = null

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Inventory Item")
            .setView(dialogView)
            .create()

        cancelButton.setOnClickListener { dialog.dismiss() }
        saveButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val category = categorySpinner.text.toString().trim()
            val quantity = quantityEditText.text.toString().toIntOrNull() ?: 0
            val unit = unitEditText.text.toString().trim()
            val threshold = thresholdEditText.text.toString().toIntOrNull() ?: 0

            if (name.isNotBlank() && category.isNotBlank() && unit.isNotBlank()) {
                val inventoryItem = InventoryItem(
                    name = name,
                    category = category,
                    quantity = quantity,
                    unit = unit,
                    lowStockThreshold = threshold
                )
                inventoryViewModel.insertInventory(inventoryItem)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun showEditInventoryDialog(item: InventoryItem) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_inventory_form, null)
        val nameEditText = dialogView.findViewById<TextInputEditText>(R.id.itemNameEditText)
        val categorySpinner = dialogView.findViewById<AutoCompleteTextView>(R.id.categorySpinner)
        val quantityEditText = dialogView.findViewById<TextInputEditText>(R.id.quantityEditText)
        val unitEditText = dialogView.findViewById<TextInputEditText>(R.id.unitEditText)
        val thresholdEditText = dialogView.findViewById<TextInputEditText>(R.id.thresholdEditText)
        val cancelButton = dialogView.findViewById<View>(R.id.cancelButton)
        val saveButton = dialogView.findViewById<View>(R.id.saveButton)

        // Pre-fill the form
        nameEditText.setText(item.name)
        categorySpinner.setText(item.category)
        quantityEditText.setText(item.quantity.toString())
        unitEditText.setText(item.unit)
        thresholdEditText.setText(item.lowStockThreshold.toString())

        // Setup category spinner
        val categories = arrayOf("Seeds", "Fertilizers", "Tools", "Equipment", "Other")
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categories)
        categorySpinner.setAdapter(categoryAdapter)
        categorySpinner.setOnClickListener { categorySpinner.showDropDown() }
        categorySpinner.keyListener = null

        val dialog = AlertDialog.Builder(this)
            .setTitle("Edit Inventory Item")
            .setView(dialogView)
            .create()

        cancelButton.setOnClickListener { dialog.dismiss() }
        saveButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val category = categorySpinner.text.toString().trim()
            val quantity = quantityEditText.text.toString().toIntOrNull() ?: 0
            val unit = unitEditText.text.toString().trim()
            val threshold = thresholdEditText.text.toString().toIntOrNull() ?: 0

            if (name.isNotBlank() && category.isNotBlank() && unit.isNotBlank()) {
                val updatedItem = item.copy(
                    name = name,
                    category = category,
                    quantity = quantity,
                    unit = unit,
                    lowStockThreshold = threshold
                )
                inventoryViewModel.updateInventory(updatedItem)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun showDeleteConfirmationDialog(item: InventoryItem) {
        AlertDialog.Builder(this)
            .setTitle("Delete Item")
            .setMessage("Are you sure you want to delete '${item.name}'?")
            .setPositiveButton("Delete") { _, _ ->
                inventoryViewModel.deleteInventory(item)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.home_toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
} 