package com.example.farmkita

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.farmkita.models.InventoryItem

@Dao
interface InventoryDao {

    @Query("SELECT * FROM inventory_table ORDER BY name ASC")
    fun getAllItems(): LiveData<List<InventoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: InventoryItem)

    @Update
    suspend fun update(item: InventoryItem)

    @Delete
    suspend fun delete(item: InventoryItem)

    @Query("DELETE FROM inventory_table")
    suspend fun clearAll()
}
