package com.example.farmkita.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.R
import com.example.farmkita.models.ActivityLog
import com.example.farmkita.models.ActivityType
import java.text.SimpleDateFormat
import java.util.*

class ActivityLogAdapter : RecyclerView.Adapter<ActivityLogAdapter.LogViewHolder>() {
    private var logs: List<ActivityLog> = emptyList()
    private var filteredLogs: List<ActivityLog> = emptyList()

    fun submitList(list: List<ActivityLog>) {
        logs = list.sortedByDescending { it.timestamp }
        filteredLogs = logs
        notifyDataSetChanged()
    }

    fun filter(keyword: String, type: ActivityType?) {
        filteredLogs = logs.filter {
            (keyword.isBlank() || it.description.contains(keyword, ignoreCase = true)) &&
            (type == null || it.type == type)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_activity_log, parent, false)
        return LogViewHolder(view)
    }

    override fun getItemCount(): Int = filteredLogs.size

    override fun onBindViewHolder(holder: LogViewHolder, position: Int) {
        holder.bind(filteredLogs[position])
    }

    class LogViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val icon: ImageView = itemView.findViewById(R.id.ivTypeIcon)
        private val description: TextView = itemView.findViewById(R.id.tvDescription)
        private val timestamp: TextView = itemView.findViewById(R.id.tvTimestamp)

        fun bind(log: ActivityLog) {
            description.text = log.description
            timestamp.text = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(log.timestamp)
            icon.setImageResource(
                when (log.type) {
                    ActivityType.TASK -> R.drawable.ic_bullet_check
                    ActivityType.JOURNAL -> R.drawable.ic_notes
                    ActivityType.EXPENSE -> R.drawable.ic_wallet
                }
            )
        }
    }
} 