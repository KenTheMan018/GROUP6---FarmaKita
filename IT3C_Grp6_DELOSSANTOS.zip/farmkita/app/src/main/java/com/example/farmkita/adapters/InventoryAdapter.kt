package com.example.farmkita.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.R
import com.example.farmkita.models.InventoryItem

class InventoryAdapter(
    private val onEditClick: (InventoryItem) -> Unit,
    private val onDeleteClick: (InventoryItem) -> Unit
) : ListAdapter<InventoryItem, InventoryAdapter.InventoryViewHolder>(InventoryDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InventoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_inventory, parent, false)
        return InventoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: InventoryViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class InventoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameText: TextView = itemView.findViewById(R.id.itemNameText)
        private val quantityText: TextView = itemView.findViewById(R.id.quantityText)
        private val categoryText: TextView = itemView.findViewById(R.id.categoryText)

        fun bind(item: InventoryItem) {
            nameText.text = item.name
            quantityText.text = "${item.quantity} ${item.unit}"
            categoryText.text = item.category

            if (item.quantity <= item.lowStockThreshold) {
                quantityText.setTextColor(
                    ContextCompat.getColor(itemView.context, R.color.error_red)
                )
            } else {
                quantityText.setTextColor(
                    ContextCompat.getColor(itemView.context, android.R.color.black)
                )
            }

            itemView.setOnClickListener {
                onEditClick(item)
            }

            itemView.setOnLongClickListener {
                onDeleteClick(item)
                true
            }
        }
    }

    class InventoryDiffCallback : DiffUtil.ItemCallback<InventoryItem>() {
        override fun areItemsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean {
            return oldItem == newItem
        }
    }
}
