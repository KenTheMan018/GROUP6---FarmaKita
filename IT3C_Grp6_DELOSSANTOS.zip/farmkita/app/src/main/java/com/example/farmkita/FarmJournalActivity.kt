package com.example.farmkita

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class FarmJournalActivity : AppCompatActivity() {

    private lateinit var etNotes: EditText
    private lateinit var etTitle: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farm_journal)

        etTitle = findViewById(R.id.etTitle)
        etNotes = findViewById(R.id.etNotes)
        btnSave = findViewById(R.id.btnSaveEntry)

        val isEdit = intent.hasExtra("position")
        val editPosition = intent.getIntExtra("position", -1)
        val editTitle = intent.getStringExtra("title") ?: ""
        val editNote = intent.getStringExtra("note") ?: ""
        val editDateTime = intent.getStringExtra("dateTime") ?: ""

        if (isEdit) {
            etTitle.setText(editTitle)
            etNotes.setText(editNote)
        }

        btnSave.setOnClickListener {
            val titleText = etTitle.text.toString().trim()
            val notesText = etNotes.text.toString().trim()

            if (titleText.isEmpty() && notesText.isEmpty()) {
                Toast.makeText(this, "Please write a title or note before saving.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val currentDateTime = if (isEdit && editDateTime.isNotEmpty()) editDateTime else SimpleDateFormat("MMMM dd, yyyy - hh:mm a", Locale.getDefault()).format(Date())

            val intent = Intent()
            intent.putExtra("title", titleText)
            intent.putExtra("note", notesText)
            intent.putExtra("dateTime", currentDateTime)
            if (isEdit) intent.putExtra("position", editPosition)
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
    }
}
