package com.example.farmkita.api

import com.example.farmkita.models.DAPrice
import com.example.farmkita.models.PSAPrice
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface DAApi {
    @GET("prices")
    fun getPrices(
        @Query("category") category: String? = null,
        @Query("search") search: String? = null
    ): Call<List<DAPrice>>
}

interface PSAApi {
    @GET("market-prices")
    fun getPrices(
        @Query("category") category: String? = null,
        @Query("search") search: String? = null
    ): Call<List<PSAPrice>>
} 