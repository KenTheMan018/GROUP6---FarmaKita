package com.example.farmkita.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.farmkita.*
import com.example.farmkita.databinding.FragmentHomeBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import java.text.SimpleDateFormat
import java.util.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.example.farmkita.FarmJournalActivity
import com.example.farmkita.JournalPageActivity

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = Firebase.auth
        sharedPreferences = requireContext().getSharedPreferences("AppSettings", Context.MODE_PRIVATE)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        setupClickListeners()
        updateTextColors()
        setupCalendar()
        setupWeather()
    }

    private fun setupUI() {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Manila"))
        val timeOfDay = when (calendar.get(Calendar.HOUR_OF_DAY)) {
            in 0..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            else -> "Good evening"
        }

        val userName = auth.currentUser?.displayName?.capitalizeWords()
            ?: auth.currentUser?.email?.split("@")?.get(0)?.capitalizeWords()
            ?: "Farmer"

        binding.greetingText.text = timeOfDay
        binding.userNameText.text = userName
        binding.moodText.text = "How are you today?"
    }

    private fun setupCalendar() {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Manila"))
        val currentDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        val dateFormat = SimpleDateFormat("d", Locale.getDefault())

        val startOfWeek = Calendar.getInstance(TimeZone.getTimeZone("Asia/Manila"))
        startOfWeek.time = calendar.time
        startOfWeek.add(Calendar.DAY_OF_MONTH, Calendar.SUNDAY - currentDayOfWeek)

        val dayBindings = listOf(
            binding.sunDate,
            binding.monDate,
            binding.tueDate,
            binding.wedDate,
            binding.thuDate,
            binding.friDate,
            binding.satDate
        )

        for (i in 0..6) {
            val day = startOfWeek.clone() as Calendar
            day.add(Calendar.DAY_OF_MONTH, i)
            dayBindings[i].text = dateFormat.format(day.time)
        }

        highlightCurrentDay(currentDayOfWeek)
    }

    private fun highlightCurrentDay(dayOfWeek: Int) {
        val dayViews = listOf(
            binding.sunDate,
            binding.monDate,
            binding.tueDate,
            binding.wedDate,
            binding.thuDate,
            binding.friDate,
            binding.satDate
        )

        for (i in dayViews.indices) {
            dayViews[i].background = null
            dayViews[i].setTextColor(ContextCompat.getColor(requireContext(), android.R.color.black))
        }

        val index = when (dayOfWeek) {
            Calendar.SUNDAY -> 0
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            else -> -1
        }

        if (index in 0..6) {
            dayViews[index].background = ContextCompat.getDrawable(requireContext(), R.drawable.current_day_background)
            dayViews[index].setTextColor(ContextCompat.getColor(requireContext(), android.R.color.white))
        }
    }

    private fun setupWeather() {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Manila"))
        val hour = calendar.get(Calendar.HOUR_OF_DAY)

        val weatherData = when {
            hour in 6..11 -> WeatherData(28.5, "Sunny", "☀️")
            hour in 12..17 -> WeatherData(32.0, "Partly Cloudy", "⛅")
            hour in 18..21 -> WeatherData(26.0, "Clear", "🌙")
            else -> WeatherData(24.0, "Clear", "🌙")
        }

        binding.weatherText.text = "${weatherData.temperature}°C ${weatherData.condition} ${weatherData.emoji}"
    }

    private data class WeatherData(
        val temperature: Double,
        val condition: String,
        val emoji: String
    )

    private fun String.capitalizeWords(): String {
        return this.split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { it.uppercase() }
        }
    }

    private fun setupClickListeners() {
        binding.viewCalendarButton.setOnClickListener {
            val calendarDialog = com.example.farmkita.CalendarDialogFragment()
            parentFragmentManager.beginTransaction()
                .add(calendarDialog, "calendar_dialog")
                .commit()
        }

        binding.tipsModule.setOnClickListener {
            try {
                val intent = Intent(requireContext(), FarmingTipsActivity::class.java)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error opening Farming Tips: \\${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.inventoryModule.setOnClickListener {
            try {
                val intent = Intent(requireContext(), InventoryActivity::class.java)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error opening Inventory Manager: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }


        binding.activityLogModule.setOnClickListener {
            try {
                val intent = Intent(requireContext(), ActivityLogActivity::class.java)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error opening Activity Log: \\${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.journalModule.setOnClickListener {
            try {
                val intent = Intent(requireContext(), JournalPageActivity::class.java)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error opening Journal Page: \\${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.expenseModule.setOnClickListener {
            try {
                val intent = Intent(requireContext(), ExpenseTrackerActivity::class.java)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error opening Expense Tracker: \\${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.taskReminderModule.setOnClickListener {
            try {
                val intent = Intent(requireContext(), TaskReminderActivity::class.java)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error opening Task Reminder: \\${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateTextColors() {
        val isDarkMode = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        val textColor = if (isDarkMode) {
            ContextCompat.getColor(requireContext(), android.R.color.white)
        } else {
            ContextCompat.getColor(requireContext(), android.R.color.black)
        }

        binding.greetingText.setTextColor(textColor)
        binding.userNameText.setTextColor(textColor)
        binding.moodText.setTextColor(textColor)
        binding.noActivitiesText.setTextColor(textColor)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
