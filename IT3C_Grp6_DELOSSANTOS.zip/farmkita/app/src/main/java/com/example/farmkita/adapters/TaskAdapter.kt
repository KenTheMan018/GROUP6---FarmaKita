package com.example.farmkita.adapters

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.R
import com.example.farmkita.models.Task

class TaskAdapter(
    private var tasks: List<Task>,
    private val onItemLongClick: (Task, Int) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    inner class TaskViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.taskTitle)
        val time: TextView = view.findViewById(R.id.taskTime)
        val checkBox: CheckBox = view.findViewById(R.id.taskCheckbox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]

        holder.title.text = task.title
        holder.time.text = task.time

        // Prevent checkbox listener from triggering during binding
        holder.checkBox.setOnCheckedChangeListener(null)
        holder.checkBox.isChecked = task.isDone

        // Apply strike-through if task is done
        holder.title.paintFlags = if (task.isDone)
            holder.title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        else
            holder.title.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()

        // Handle checkbox change
        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
            task.isDone = isChecked
            holder.title.paintFlags = if (isChecked)
                holder.title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            else
                holder.title.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        }

        // Long press to edit or delete
        holder.itemView.setOnLongClickListener {
            onItemLongClick(task, position)
            true
        }
    }

    override fun getItemCount(): Int = tasks.size

    fun updateList(newTasks: List<Task>) {
        tasks = newTasks
        notifyDataSetChanged()
    }
}
