package com.example.farmkita.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.farmkita.databinding.DialogCropCalculatorBinding
import java.text.NumberFormat
import java.util.Locale

class CropCalculatorDialog : DialogFragment() {
    private var _binding: DialogCropCalculatorBinding? = null
    private val binding get() = _binding!!
    private val numberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return Dialog(requireContext()).apply {
            setCancelable(true)
            setCanceledOnTouchOutside(true)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogCropCalculatorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.calculateButton.setOnClickListener {
            performCalculation()
        }

        binding.saveButton.setOnClickListener {
            saveCalculation()
        }
    }

    private fun performCalculation() {
        try {
            val landArea = binding.landAreaInput.text.toString().toDoubleOrNull() ?: 0.0
            val yield = binding.yieldInput.text.toString().toDoubleOrNull() ?: 0.0
            val price = binding.priceInput.text.toString().toDoubleOrNull() ?: 0.0
            val cost = binding.costInput.text.toString().toDoubleOrNull() ?: 0.0

            if (landArea <= 0 || yield <= 0 || price <= 0) {
                Toast.makeText(context, "Please enter valid values", Toast.LENGTH_SHORT).show()
                return
            }

            // Calculate results
            val totalYield = landArea * yield
            val grossRevenue = totalYield * price
            val netProfit = grossRevenue - cost
            val roi = if (cost > 0) ((netProfit / cost) * 100) else 0.0

            // Display results
            binding.totalYieldResult.text = String.format("%.2f kg", totalYield)
            binding.grossRevenueResult.text = numberFormat.format(grossRevenue)
            binding.netProfitResult.text = numberFormat.format(netProfit)
            binding.roiResult.text = String.format("%.1f%%", roi)

            // Show results container
            binding.resultsContainer.visibility = View.VISIBLE

        } catch (e: Exception) {
            Toast.makeText(context, "Error in calculation: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveCalculation() {
        // TODO: Implement saving calculation to database or shared preferences
        Toast.makeText(context, "Calculation saved successfully!", Toast.LENGTH_SHORT).show()
        dismiss()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 