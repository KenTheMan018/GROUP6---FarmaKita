package com.example.farmkita.models

import java.text.NumberFormat
import java.util.Locale

data class CropCalculation(
    val cropName: String,
    val landSize: Double,
    val seedCost: Double,
    val fertilizerCost: Double,
    val laborCost: Double,
    val sellingPricePerKg: Double,
    val expectedYieldPerHectare: Double
) {
    val totalExpenses: Double
        get() = (seedCost + fertilizerCost + laborCost) * landSize

    val totalRevenue: Double
        get() = expectedYieldPerHectare * landSize * sellingPricePerKg

    val netProfit: Double
        get() = totalRevenue - totalExpenses

    val profitMargin: Double
        get() = if (totalExpenses > 0) (netProfit / totalExpenses) * 100 else 0.0

    val roi: Double
        get() = if (totalExpenses != 0.0) (netProfit / totalExpenses) * 100 else 0.0

    companion object {
        private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
        private val percentFormat = NumberFormat.getPercentInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 2
        }

        fun formatCurrency(value: Double): String {
            return "₱%.2f".format(value)
        }

        fun formatPercentage(value: Double): String {
            return "%.2f%%".format(value)
        }
    }
} 