package com.example.farmkita.models

data class JournalEntry(
    val title: String,
    val note: String,
    val dateTime: String
) 