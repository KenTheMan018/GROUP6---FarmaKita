package com.example.farmkita.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.farmkita.R
import com.example.farmkita.models.JournalEntry

class JournalAdapter(
    private var journalList: List<JournalEntry>,
    private val onItemClick: (JournalEntry, Int) -> Unit
) : RecyclerView.Adapter<JournalAdapter.JournalViewHolder>() {

    class JournalViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.tvEntryTitle)
        val note: TextView = itemView.findViewById(R.id.tvEntryPreview)
        val dateTime: TextView = itemView.findViewById(R.id.tvEntryDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JournalViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_journal_card, parent, false)
        return JournalViewHolder(view)
    }

    override fun onBindViewHolder(holder: JournalViewHolder, position: Int) {
        val entry = journalList[position]
        holder.title.text = entry.title
        holder.note.text = entry.note
        holder.dateTime.text = entry.dateTime
        holder.itemView.setOnClickListener { onItemClick(entry, position) }
    }

    override fun getItemCount(): Int = journalList.size

    fun updateList(newList: List<JournalEntry>) {
        journalList = newList
        notifyDataSetChanged()
    }
} 