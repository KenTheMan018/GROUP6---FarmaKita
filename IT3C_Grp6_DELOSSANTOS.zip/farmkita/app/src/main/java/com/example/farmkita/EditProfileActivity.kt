package com.example.farmkita

import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivityEditProfileBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class EditProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEditProfileBinding
    private lateinit var auth: FirebaseAuth
    private val database = Firebase.database.reference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        setupToolbar()
        loadUserData()
        setupClickListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
            setDisplayShowTitleEnabled(false)
        }
        binding.toolbar.title = "Edit Profile"
        binding.toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun loadUserData() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // First, set the display name from Firebase Auth as default
            currentUser.displayName?.let { displayName ->
                if (displayName.isNotEmpty()) {
                    val nameParts = displayName.split(" ")
                    if (nameParts.size >= 2) {
                        binding.firstNameEditText.setText(nameParts[0].capitalizeWords())
                        binding.lastNameEditText.setText(nameParts.drop(1).joinToString(" ").capitalizeWords())
                    } else {
                        binding.firstNameEditText.setText(displayName.capitalizeWords())
                    }
                }
            }
            
            // Load user data from Firebase Database
            database.child("users").child(currentUser.uid).get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot.exists()) {
                        val name = snapshot.child("name").value as? String
                        val firstName = snapshot.child("firstName").value as? String
                        val lastName = snapshot.child("lastName").value as? String
                        val phone = snapshot.child("phone").value as? String
                        val address = snapshot.child("address").value as? String

                        // Use database data if available
                        if (!firstName.isNullOrEmpty()) {
                            binding.firstNameEditText.setText(firstName.capitalizeWords())
                        }
                        if (!lastName.isNullOrEmpty()) {
                            binding.lastNameEditText.setText(lastName.capitalizeWords())
                        }
                        
                        // Fallback to old name format if firstName/lastName not available
                        if ((firstName.isNullOrEmpty() || lastName.isNullOrEmpty()) && !name.isNullOrEmpty()) {
                            val nameParts = name.split(" ")
                            if (nameParts.size >= 2) {
                                binding.firstNameEditText.setText(nameParts[0].capitalizeWords())
                                binding.lastNameEditText.setText(nameParts.drop(1).joinToString(" ").capitalizeWords())
                            } else {
                                binding.firstNameEditText.setText(name.capitalizeWords())
                            }
                        }
                        
                        binding.phoneEditText.setText(phone)
                        binding.addressEditText.setText(address)
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error loading user data", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun setupClickListeners() {
        binding.saveButton.setOnClickListener {
            saveUserData()
        }
    }

    private fun saveUserData() {
        val firstName = binding.firstNameEditText.text.toString().trim().capitalizeWords()
        val lastName = binding.lastNameEditText.text.toString().trim().capitalizeWords()
        val phone = binding.phoneEditText.text.toString().trim()
        val address = binding.addressEditText.text.toString().trim()
        val fullName = "$firstName $lastName".trim()

        // Validate input
        if (TextUtils.isEmpty(firstName)) {
            binding.firstNameLayout.error = "First name is required"
            return
        }
        if (TextUtils.isEmpty(lastName)) {
            binding.lastNameLayout.error = "Last name is required"
            return
        }
        if (TextUtils.isEmpty(phone)) {
            binding.phoneLayout.error = "Phone number is required"
            return
        }

        // Clear any previous errors
        binding.firstNameLayout.error = null
        binding.lastNameLayout.error = null
        binding.phoneLayout.error = null

        // Show loading state
        binding.saveButton.isEnabled = false
        binding.saveButton.text = "Saving..."

        val currentUser = auth.currentUser
        if (currentUser != null) {
            val userData = mapOf(
                "firstName" to firstName,
                "lastName" to lastName,
                "name" to fullName, // Keep for backward compatibility
                "phone" to phone,
                "address" to address
            )

            // Update Firebase Database
            database.child("users").child(currentUser.uid).updateChildren(userData)
                .addOnSuccessListener {
                    // Also update Firebase Auth displayName
                    val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(fullName)
                        .build()

                    currentUser.updateProfile(profileUpdates)
                        .addOnSuccessListener {
                            showSuccessDialog()
                        }
                        .addOnFailureListener { profileError ->
                            showSuccessDialog() // Still show success even if display name fails
                        }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error updating profile: ${it.message}", Toast.LENGTH_SHORT).show()
                    binding.saveButton.isEnabled = true
                    binding.saveButton.text = "Save Changes"
                }
        }
    }

    private fun showSuccessDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Success!")
            .setMessage("Your profile information has been updated successfully.")
            .setPositiveButton("OK") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun String.capitalizeWords(): String {
        return this.split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { it.uppercase() }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
} 