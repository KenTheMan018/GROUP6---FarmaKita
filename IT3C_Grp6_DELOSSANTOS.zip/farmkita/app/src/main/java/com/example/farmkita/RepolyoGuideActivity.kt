package com.example.farmkita

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivityFarmingSeedCardBinding

class RepolyoGuideActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFarmingSeedCardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFarmingSeedCardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = "🥬 Repolyo Growing Guide"
        val iconResId = R.drawable.ic_repolyo // Ensure this drawable exists in res/drawable
        val guide = """
🥬 How to Take Care of Repolyo (Cabbage) from Planting to Harvest

Repolyo (cabbage) is a cool-weather crop that's rich in nutrients and widely used in Filipino cooking. It grows best in well-prepared soil with proper spacing, watering, and pest control. Here's how to grow healthy repolyo from seedling to harvest.

🌱 1. Planning and Preparation  
✅ Tips:  
• Choose a cool growing season — ideally during the ber months (September to February) in the Philippines.  
• Select a sunny area with well-drained, fertile soil rich in organic matter.  
• Aim for soil with a pH between 6.0 and 6.8.  

🚨 Reminders:  
• Avoid planting in the same spot where cabbage family crops (like pechay, broccoli, or cauliflower) were recently grown — this helps prevent disease buildup.  
• Remove rocks, old roots, and debris from the soil to promote healthy root growth.  

🌾 2. Sowing the Seeds / Transplanting  
✅ Tips:  
• Start with seeds in seed trays or containers using seedling soil mix.  
• Transplant seedlings when they’re about 4–5 inches tall, with 4–5 true leaves.  
• Space transplants 12–18 inches apart, in rows about 18–24 inches apart.  

🚨 Reminders:  
• Harden off seedlings by gradually exposing them to outdoor sunlight before transplanting.  
• Avoid disturbing roots during transplanting to reduce transplant shock.  

🌿 3. Early Growth and Maintenance  
✅ Tips:  
• Water regularly, keeping the soil consistently moist but not soggy.  
• Mulch around the base to retain moisture and suppress weeds.  
• Fertilize 2–3 weeks after transplanting with balanced fertilizer (e.g., 14-14-14 or 10-10-10).  

🚨 Reminders:  
• Uneven watering can cause cabbage heads to split or crack.  
• Don’t apply fertilizer too close to the plant stem — apply it in a ring around the plant.  

💧 4. Watering and Fertilizing  
✅ Tips:  
• Cabbage needs 1–1.5 inches of water per week, more during dry spells.  
• Use compost or aged manure as organic fertilizer to improve soil condition.  
• Apply urea or nitrogen-rich fertilizer early in growth, and switch to potassium-rich fertilizer once heads begin forming.  

🚨 Reminders:  
• Water at the base — wet leaves can attract fungus and pests.  
• Over-fertilizing can lead to excess leafy growth but small heads.  

🐛 5. Pest and Disease Management  
✅ Tips:  
• Use netting or row covers to protect against cabbage worms and leaf miners.  
• Apply organic pest sprays (like neem oil or chili-garlic spray) to control aphids and caterpillars.  
• Regularly check the undersides of leaves for pests or eggs.  

🚨 Reminders:  
• Remove and destroy heavily infested or diseased leaves.  
• Rotate crops yearly to prevent buildup of soil-borne diseases like clubroot or black rot.  

🥬 6. Harvesting Repolyo  
✅ Tips:  
• Harvest when the head feels firm and full-sized (typically 70–90 days from transplanting, depending on variety).  
• Use a sharp knife to cut the head at the base, leaving the outer leaves for protection.  

🚨 Reminders:  
• Don’t wait too long — overripe heads may crack or bolt (produce flowers).  
• Handle gently to avoid bruising the head.  

🧊 7. Post-Harvest Handling and Storage  
✅ Tips:  
• Store repolyo in a cool, shaded area if not used immediately.  
• Refrigerate in a plastic bag or container to keep fresh for up to 2 weeks.  

🚨 Reminders:  
• Don’t wash cabbage before storing — only wash when ready to cook.  
• Keep away from ethylene-producing fruits like apples and bananas, which cause it to spoil faster.  

📌 Additional Tips and Reminders  
✅ Tips:  
• Plant marigolds, garlic, or basil nearby — they help repel cabbage pests naturally.  
• Remove weeds regularly — they compete for nutrients and attract pests.  
• Choose resistant varieties if your area has a history of cabbage diseases.  

🚨 Reminders:  
• Clean tools and hands before handling plants to prevent disease spread.  
• Dispose of leftover plant debris properly after harvest to avoid harboring pests.
""".trimIndent()

        // Set values to UI
        binding.seedIcon.setImageResource(iconResId)
        binding.seedName.text = name
        binding.seedGuide.text = guide
        binding.toolbar.title = name
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }
}
