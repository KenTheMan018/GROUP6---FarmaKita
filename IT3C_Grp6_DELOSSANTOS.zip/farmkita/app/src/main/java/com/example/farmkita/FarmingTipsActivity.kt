package com.example.farmkita

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.farmkita.adapters.SeedTipAdapter
import com.example.farmkita.databinding.ActivityFarmingTipsBinding
import com.example.farmkita.models.SeedTip
import com.google.android.material.chip.Chip

class FarmingTipsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFarmingTipsBinding
    private lateinit var seedAdapter: SeedTipAdapter
    private lateinit var seedList: List<SeedTip>
    private var selectedCategory: String? = null
    private var currentQuery: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFarmingTipsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupSeedList()
        setupRecyclerView(seedList)
        setupChips()
        setupSearch()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Farming Tips & Reminders"
        }
        binding.toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupSeedList() {
        seedList = listOf(
            SeedTip(
                name = "Carrot",
                iconResId = R.drawable.ic_carrot,
                category = "Root Crop",
                guide = "🥕 How to Take Care of Carrots from Seeds to Harvest...\n\n..."
            ),
            SeedTip(
                name = "Potato",
                iconResId = R.drawable.ic_patatoe,
                category = "Root Crop",
                guide = "🥔 How to Take Care of Potatoes from Planting to Harvest...\n\n..."
            ),
            SeedTip(
                name = "Kalabasa",
                iconResId = R.drawable.ic_kalabasa,
                category = "Fruit Vegetable",
                guide = "🎃 How to Take Care of Kalabasa (Squash) from Planting to Harvest...\n\n..."
            ),
            SeedTip(
                name = "Mango",
                iconResId = R.drawable.ic_mango,
                category = "Fruit Tree",
                guide = "🥭 How to Take Care of Mango Trees from Planting to Harvest...\n\n..."
            ),

            SeedTip(
                name = "Repolyo",
                iconResId = R.drawable.ic_repolyo,
                category = "Leafy Vegetable",
                guide = "\uD83E\uDD6C How to Take Care of Repolyo (Cabbage) from Planting to Harve.....\n\n..."
            )
        )
    }


    private fun setupRecyclerView(seedItems: List<SeedTip>) {
        binding.seedRecyclerView.layoutManager = LinearLayoutManager(this)
        seedAdapter = SeedTipAdapter(seedItems) { seed ->
            val intent = when (seed.name) {
                "Carrot" -> Intent(this, CarrotGuideActivity::class.java)
                "Potato" -> Intent(this, PotatoGuideActivity::class.java)
                "Kalabasa" -> Intent(this, KalabasaGuideActivity::class.java)
                "Mango" -> Intent(this, MangoGuideActivity::class.java)
                else -> Intent(this, FarmingSeedCardActivity::class.java)
            }

            intent.putExtra("seedName", seed.name)
            intent.putExtra("seedIconResId", seed.iconResId)
            intent.putExtra("seedGuide", seed.guide)
            startActivity(intent)
        }
        binding.seedRecyclerView.adapter = seedAdapter
    }

    private fun setupChips() {
        val chipGroup = binding.categoryChipGroup
        chipGroup.removeAllViews()

        val allChip = Chip(this).apply {
            text = "All"
            isCheckable = true
            isChecked = true
        }
        chipGroup.addView(allChip)

        val categories = seedList.map { it.category }.distinct().sorted()
        for (category in categories) {
            val chip = Chip(this).apply {
                text = category
                isCheckable = true
            }
            chipGroup.addView(chip)
        }

        chipGroup.setOnCheckedChangeListener { group, checkedId ->
            val chip = group.findViewById<Chip>(checkedId)
            selectedCategory = if (chip != null && chip.text != "All") chip.text.toString() else null
            filterSeeds(currentQuery)
        }
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                currentQuery = s?.toString()
                filterSeeds(currentQuery)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun filterSeeds(query: String?) {
        val filteredList = seedList.filter {
            (query.isNullOrBlank() || it.name.contains(query, true) || it.category.contains(query, true)) &&
                    (selectedCategory == null || it.category == selectedCategory)
        }
        setupRecyclerView(filteredList)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
