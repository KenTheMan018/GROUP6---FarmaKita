package com.example.farmkita

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivityFarmingSeedCardBinding

class PotatoGuideActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFarmingSeedCardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFarmingSeedCardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = "🥔 Potato Growing Guide"
        val iconResId = R.drawable.ic_patatoe // make sure this drawable exists
        val guide = """
🥔 How to Take Care of Potatoes from Planting to Harvest

Potatoes are a cool-season crop that grow underground from pieces of tubers called "seed potatoes." With proper planting, hilling, and care, you can enjoy a bountiful harvest of fresh, homegrown spuds. Here’s a complete guide to help you grow them step by step:

🌱 1. Planning and Preparation  
✅ Tips:  
• Choose certified disease-free seed potatoes from a garden center or co-op.  
• Cut large seed potatoes into chunks, each with 1–2 eyes (buds), and let them dry for 1–2 days before planting.  
• Select a sunny spot with at least 6 hours of sunlight daily.  
• Prepare loose, well-drained soil rich in organic matter.  

🚨 Reminders:  
• Don’t plant store-bought eating potatoes — they may carry disease or be chemically treated.  
• Avoid planting in the same area where tomatoes or potatoes were grown in the past 1–2 years.  

🌾 2. Planting the Potatoes  
✅ Tips:  
• Plant seed pieces 4 inches deep, with eyes facing up, and space them 12 inches apart in rows.  
• Space rows about 2–3 feet apart to allow for hilling later.  
• Cover with soil and water lightly after planting.  

🚨 Reminders:  
• Wait until soil temperature is at least 7°C–10°C (45°F–50°F) before planting.  
• Avoid planting in wet or waterlogged soil — it can cause seed pieces to rot.  

🌿 3. Early Growth and Hilling  
✅ Tips:  
• When plants are about 6–8 inches tall, hill soil around the base to cover the lower stems.  
• Repeat hilling every couple of weeks or after heavy rain, until hills are 10–12 inches high.  
• Hilling protects tubers from sunlight (which turns them green and toxic) and encourages more tubers to form.  

🚨 Reminders:  
• Do not expose developing tubers — green potatoes contain solanine, which is harmful.  
• Be gentle during hilling to avoid damaging roots and stems.  

💧 4. Watering and Feeding  
✅ Tips:  
• Water regularly — 1–2 inches per week, especially during tuber formation (about 6–10 weeks after planting).  
• Use compost or balanced fertilizer during early growth.  
• Stop watering when leaves begin to yellow and die back (2–3 weeks before harvest) to help cure tubers.  

🚨 Reminders:  
• Overwatering can lead to rot and fungal diseases.  
• Water at the base — avoid getting leaves wet to reduce disease risk.  

🥔 5. Harvesting the Potatoes  
✅ Tips:  
• You can harvest "new potatoes" (small and tender) about 2–3 weeks after flowering.  
• For full-sized potatoes, wait until the foliage dies back completely (typically 90–120 days).  
• Use a garden fork to gently lift tubers without bruising or cutting them.  

🚨 Reminders:  
• Let tubers dry briefly in the sun after harvesting, but don’t leave them exposed too long.  
• Handle gently — damaged potatoes spoil faster in storage.  

🧊 6. Storing Potatoes  
✅ Tips:  
• Cure potatoes in a cool, dark, well-ventilated place for 1–2 weeks.  
• After curing, store them in a dark, dry place at 4°C–10°C (40°F–50°F), like a cellar or pantry.  
• Store in breathable bags or crates (not plastic).  

🚨 Reminders:  
• Keep potatoes away from light — exposure causes greening and bitterness.  
• Do not store near onions — they release gases that cause spoilage.  

📌 Additional Tips and Reminders  
✅ Tips:  
• Practice crop rotation to prevent soil-borne diseases and pests.  
• Mulch around plants to retain moisture and reduce weed competition.  

🚨 Reminders:  
• Watch for common potato pests like Colorado potato beetles and aphids.  
• Remove infected plants immediately to prevent the spread of blight or viruses.
""".trimIndent()

        // Apply values to UI
        binding.seedIcon.setImageResource(iconResId)
        binding.seedName.text = name
        binding.seedGuide.text = guide
        binding.toolbar.title = name
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }
}
