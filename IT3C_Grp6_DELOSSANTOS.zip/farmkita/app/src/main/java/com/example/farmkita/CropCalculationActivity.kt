package com.example.farmkita

import android.content.Intent
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.farmkita.databinding.ActivityCropcalculationBinding
import com.example.farmkita.models.CropCalculation
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import android.Manifest
import android.util.Log
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts

class CropCalculationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCropcalculationBinding
    private lateinit var sharedPreferences: SharedPreferences
    private var currentCalculation: CropCalculation? = null
    private var calculationResultShown = false
    private var lastCalculationDescription: String? = null

    private val cropYieldRanges = mapOf(
        "rice" to "3,000 - 6,000",
        "corn" to "4,000 - 8,000",
        "tomato" to "15,000 - 30,000",
        "pechay" to "8,000 - 15,000",
        "kangkong" to "10,000 - 20,000",
        "ampalaya" to "8,000 - 15,000",
        "squash" to "12,000 - 25,000",
        "eggplant" to "10,000 - 20,000",
        "okra" to "8,000 - 15,000",
        "string beans" to "5,000 - 10,000",
        "cabbage" to "15,000 - 30,000",
        "carrots" to "20,000 - 35,000",
        "potatoes" to "15,000 - 25,000",
        "onions" to "8,000 - 15,000",
        "garlic" to "3,000 - 6,000",
        "ginger" to "10,000 - 20,000",
        "banana" to "15,000 - 30,000",
        "mango" to "8,000 - 15,000",
        "papaya" to "20,000 - 40,000",
        "pineapple" to "25,000 - 50,000"
    )

    private val EXPORT_PDF = 1
    private val EXPORT_EXCEL = 2
    private val EXPORT_WORD = 3
    private val STORAGE_PERMISSION_CODE = 100

    private val exportPDFToCustomLocationLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val uri = result.data!!.data
            if (uri != null) {
                exportPDFToUri(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCropcalculationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("FarmkitaPrefs", MODE_PRIVATE)
        setupToolbar()
        setupCropTypeDropdown()
        setupInputListeners()
        setupCalculateButton()
        updateCalculateButtonState()
        applyTheme()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Crop Calculator"
        }
        binding.toolbar.menu?.clear()
    }

    private fun setupCropTypeDropdown() {
        val cropTypes = listOf(
            "Dry Palay", "Corn", "Tomato", "Pechay", "Kangkong", "Ampalaya", "Squash", "Eggplant", "Okra", "String Beans", "Cabbage", "Carrots", "Potatoes", "Onions", "Garlic", "Ginger", "Banana", "Mango", "Papaya", "Pineapple"
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, cropTypes)
        binding.cropNameInput.setAdapter(adapter)
    }

    private fun setupInputListeners() {
        binding.cropNameInput.addTextChangedListener(createTextWatcher())
        binding.landSizeInput.addTextChangedListener(createTextWatcher())
        binding.seedCostInput.addTextChangedListener(createTextWatcher())
        binding.fertilizerCostInput.addTextChangedListener(createTextWatcher())
        binding.laborCostInput.addTextChangedListener(createTextWatcher())
        binding.sellingPriceInput.addTextChangedListener(createTextWatcher())
        binding.expectedYieldInput.addTextChangedListener(createTextWatcher())

        binding.cropNameInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateYieldRecommendation(s.toString())
            }
        })
    }

    private fun createTextWatcher(): TextWatcher {
        return object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateCalculateButtonState()
                clearFieldErrors()
            }
        }
    }

    private fun updateYieldRecommendation(cropName: String) {
        val cropKey = cropName.lowercase().trim()
        val recommendedYield = cropYieldRanges[cropKey]

        if (!recommendedYield.isNullOrEmpty()) {
            binding.expectedYieldLayout.helperText = "Recommended: $recommendedYield kg/hectare"
            binding.expectedYieldLayout.setHelperTextColor(
                ContextCompat.getColorStateList(this, android.R.color.holo_green_dark)
            )
            binding.cropNameLayout.helperText = "Crop found! Yield recommendation available."
            binding.cropNameLayout.setHelperTextColor(
                ContextCompat.getColorStateList(this, android.R.color.holo_green_dark)
            )
        } else if (cropName.isNotEmpty()) {
            binding.expectedYieldLayout.helperText = "Enter expected yield in kg per hectare"
            binding.expectedYieldLayout.setHelperTextColor(
                ContextCompat.getColorStateList(this, android.R.color.darker_gray)
            )
            binding.cropNameLayout.helperText = "Try: rice, corn, tomato, pechay, kangkong, etc."
            binding.cropNameLayout.setHelperTextColor(
                ContextCompat.getColorStateList(this, android.R.color.darker_gray)
            )
        } else {
            binding.expectedYieldLayout.helperText = "Enter expected yield in kg per hectare"
            binding.expectedYieldLayout.setHelperTextColor(
                ContextCompat.getColorStateList(this, android.R.color.darker_gray)
            )
            binding.cropNameLayout.helperText = "Enter crop name (e.g., rice, corn, tomato)"
            binding.cropNameLayout.setHelperTextColor(
                ContextCompat.getColorStateList(this, android.R.color.darker_gray)
            )
        }
    }

    private fun updateCalculateButtonState() {
        val isComplete = areAllFieldsFilled()
        binding.calculateButton.isEnabled = isComplete

        if (isComplete) {
            binding.calculateButton.alpha = 1.0f
            binding.calculateButton.text = "Calculate Profit"
            binding.calculateButton.setTextAppearance(R.style.FarmkitaButton)
        } else {
            binding.calculateButton.alpha = 0.8f
            binding.calculateButton.text = "Complete all fields to calculate"
            binding.calculateButton.setTextAppearance(R.style.FarmkitaButtonDisabled)
        }
    }

    private fun areAllFieldsFilled(): Boolean {
        return with(binding) {
            !TextUtils.isEmpty(cropNameInput.text) &&
                    !TextUtils.isEmpty(landSizeInput.text) &&
                    !TextUtils.isEmpty(seedCostInput.text) &&
                    !TextUtils.isEmpty(fertilizerCostInput.text) &&
                    !TextUtils.isEmpty(sellingPriceInput.text) &&
                    !TextUtils.isEmpty(expectedYieldInput.text)
        }
    }

    private fun clearFieldErrors() {
        with(binding) {
            cropNameLayout.error = null
            landSizeLayout.error = null
            seedCostLayout.error = null
            fertilizerCostLayout.error = null
            laborCostLayout.error = null
            sellingPriceLayout.error = null
            expectedYieldLayout.error = null
        }
    }

    private fun setupCalculateButton() {
        binding.calculateButton.setOnClickListener {
            if (validateInputs()) {
                calculateProfit()
            }
        }
    }

    private fun validateInputs(): Boolean {
        with(binding) {
            if (TextUtils.isEmpty(cropNameInput.text)) {
                cropNameLayout.error = "Please enter crop name"
                return false
            }
            cropNameLayout.error = null

            if (TextUtils.isEmpty(landSizeInput.text)) {
                landSizeLayout.error = "Please enter land size"
                return false
            }
            landSizeLayout.error = null

            if (TextUtils.isEmpty(seedCostInput.text)) {
                seedCostLayout.error = "Please enter seed cost"
                return false
            }
            seedCostLayout.error = null

            if (TextUtils.isEmpty(fertilizerCostInput.text)) {
                fertilizerCostLayout.error = "Please enter fertilizer cost"
                return false
            }
            fertilizerCostLayout.error = null

            laborCostLayout.error = null

            if (TextUtils.isEmpty(sellingPriceInput.text)) {
                sellingPriceLayout.error = "Please enter selling price"
                return false
            }
            sellingPriceLayout.error = null

            if (TextUtils.isEmpty(expectedYieldInput.text)) {
                expectedYieldLayout.error = "Please enter expected yield"
                return false
            }
            expectedYieldLayout.error = null

            return true
        }
    }

    private fun calculateProfit() {
        try {
            with(binding) {
                val laborCostValue = if (TextUtils.isEmpty(laborCostInput.text)) 0.0 else laborCostInput.text.toString().toDouble()
                val calculation = CropCalculation(
                    cropName = cropNameInput.text.toString(),
                    landSize = landSizeInput.text.toString().toDouble(),
                    seedCost = seedCostInput.text.toString().toDouble(),
                    fertilizerCost = fertilizerCostInput.text.toString().toDouble(),
                    laborCost = laborCostValue,
                    sellingPricePerKg = sellingPriceInput.text.toString().toDouble(),
                    expectedYieldPerHectare = expectedYieldInput.text.toString().toDouble()
                )

                currentCalculation = calculation

                val totalYield = calculation.landSize * calculation.expectedYieldPerHectare
                val totalRevenue = totalYield * calculation.sellingPricePerKg
                val totalCost = calculation.seedCost + calculation.fertilizerCost + calculation.laborCost
                val profit = totalRevenue - totalCost
                val profitMargin = if (totalRevenue > 0) (profit / totalRevenue) * 100 else 0.0
                val roi = if (totalCost > 0) (profit / totalCost) * 100 else 0.0

                showCalculationResult(totalCost, totalRevenue, profit, profitMargin, roi)
            }
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCalculationResult(totalCost: Double, totalRevenue: Double, profit: Double, profitMargin: Double, roi: Double) {
        binding.resultsCard.visibility = android.view.View.VISIBLE
        binding.totalExpensesText.text = CropCalculation.formatCurrency(totalCost)
        binding.totalRevenueText.text = CropCalculation.formatCurrency(totalRevenue)
        binding.netProfitText.text = CropCalculation.formatCurrency(profit)
        binding.profitMarginText.text = CropCalculation.formatPercentage(profitMargin)
        binding.roiText.text = CropCalculation.formatPercentage(roi)
        calculationResultShown = true
        lastCalculationDescription = "Crop: ${binding.cropNameInput.text}, Land: ${binding.landSizeInput.text}ha, Profit: ${CropCalculation.formatCurrency(profit)}"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.activity_cropcalculation_menu, menu)
        updateThemeIcon(menu.findItem(R.id.action_theme_toggle))
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        Log.d("CropCalc", "onOptionsItemSelected: ${item.itemId}")
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            R.id.action_theme_toggle -> {
                toggleTheme()
                true
            }
            R.id.action_export_report -> {
                showExportOptions()
                true
            }
            EXPORT_PDF -> {
                exportAsPDF()
                true
            }
            EXPORT_EXCEL -> {
                exportAsExcel()
                true
            }
            EXPORT_WORD -> {
                exportAsWord()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun toggleTheme() {
        val currentMode = AppCompatDelegate.getDefaultNightMode()
        val newMode = when (currentMode) {
            AppCompatDelegate.MODE_NIGHT_YES -> AppCompatDelegate.MODE_NIGHT_NO
            else -> AppCompatDelegate.MODE_NIGHT_YES
        }

        AppCompatDelegate.setDefaultNightMode(newMode)
        sharedPreferences.edit().putInt("theme_mode", newMode).apply()
        updateThemeIcon(binding.toolbar.menu.findItem(R.id.action_theme_toggle))
    }

    private fun updateThemeIcon(menuItem: MenuItem?) {
        menuItem?.let {
            val isDarkMode = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
            it.setIcon(if (isDarkMode) R.drawable.ic_sun else R.drawable.ic_moon)
        }
    }

    private fun applyTheme() {
        val savedTheme = sharedPreferences.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(savedTheme)
    }

    private fun showExportOptions() {
        Log.d("CropCalc", "showExportOptions called")
        val popup = android.widget.PopupMenu(this, binding.toolbar.findViewById(R.id.action_export_report))
        popup.menu.add(0, EXPORT_PDF, 0, "Export as PDF (App Documents)")
        popup.menu.add(0, EXPORT_EXCEL, 1, "Export as Excel")
        popup.menu.add(0, EXPORT_WORD, 2, "Export as Word")
        popup.menu.add(0, 1001, 3, "Export PDF to Custom Location")
        popup.setOnMenuItemClickListener { menuItem ->
            Log.d("CropCalc", "Export option selected: ${menuItem.itemId}")
            when (menuItem.itemId) {
                EXPORT_PDF -> exportAsPDF()
                EXPORT_EXCEL -> exportAsExcel()
                EXPORT_WORD -> exportAsWord()
                1001 -> exportPDFToCustomLocation()
            }
            true
        }
        popup.show()
    }

    private fun checkStoragePermission(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                true
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    STORAGE_PERMISSION_CODE
                )
                false
            }
        } else {
            true
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            exportAsPDF()
        }
    }

    private fun exportAsPDF() {
        Toast.makeText(this, "DEBUG: exportAsPDF called", Toast.LENGTH_SHORT).show()
        Log.d("CropCalc", "exportAsPDF called")
        if (currentCalculation == null) {
            Toast.makeText(this, "Please calculate first before exporting", Toast.LENGTH_SHORT).show()
            Log.d("CropCalc", "No calculation to export")
            return
        }
        if (!checkStoragePermission()) {
            Log.d("CropCalc", "Storage permission not granted")
            return
        }
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "crop_calculation_$timestamp.pdf"
            val downloadsDir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            val file = File(downloadsDir, fileName)

            val document = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply {
                color = Color.BLACK
                textSize = 12f
            }

            val content = generateReportContent()
            var yPosition = 40f
            content.lines().forEach { line ->
                canvas.drawText(line, 40f, yPosition, paint)
                yPosition += paint.descent() - paint.ascent()
            }

            document.finishPage(page)
            FileOutputStream(file).use { output ->
                document.writeTo(output)
            }
            document.close()

            Toast.makeText(this, "PDF exported to: ${file.absolutePath}", Toast.LENGTH_LONG).show()
            Log.d("CropCalc", "PDF exported to: ${file.absolutePath}")
            openFileInFileManager(file, "application/pdf")
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to export PDF: ${e.message}", Toast.LENGTH_SHORT).show()
            Log.e("CropCalc", "Failed to export PDF", e)
        }
    }

    private fun exportAsExcel() {
        if (currentCalculation == null) {
            Toast.makeText(this, "Please calculate first before exporting", Toast.LENGTH_SHORT).show()
            return
        }
        if (!checkStoragePermission()) {
            return
        }
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "crop_calculation_$timestamp.csv"
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsDir, fileName)
            val content = generateCSVContent()
            file.writeText(content)
            Toast.makeText(this, "Excel file exported to: ${file.absolutePath}", Toast.LENGTH_LONG).show()
            openFileInFileManager(file, "text/csv")
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to export Excel: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportAsWord() {
        if (currentCalculation == null) {
            Toast.makeText(this, "Please calculate first before exporting", Toast.LENGTH_SHORT).show()
            return
        }
        if (!checkStoragePermission()) {
            return
        }
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "crop_calculation_$timestamp.doc"
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsDir, fileName)
            val content = generateReportContent()
            file.writeText(content)
            Toast.makeText(this, "Word document exported to: ${file.absolutePath}", Toast.LENGTH_LONG).show()
            openFileInFileManager(file, "application/msword")
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to export Word document: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportPDFToCustomLocation() {
        if (currentCalculation == null) {
            Toast.makeText(this, "Please calculate first before exporting", Toast.LENGTH_SHORT).show()
            return
        }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "crop_calculation_$timestamp.pdf"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
        exportPDFToCustomLocationLauncher.launch(intent)
    }

    private fun exportPDFToUri(uri: Uri) {
        try {
            val document = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply {
                color = Color.BLACK
                textSize = 12f
            }
            val content = generateReportContent()
            var yPosition = 40f
            content.lines().forEach { line ->
                canvas.drawText(line, 40f, yPosition, paint)
                yPosition += paint.descent() - paint.ascent()
            }
            document.finishPage(page)
            contentResolver.openOutputStream(uri)?.use { output ->
                document.writeTo(output)
            }
            document.close()
            Toast.makeText(this, "PDF exported to custom location!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to export PDF: ${e.message}", Toast.LENGTH_SHORT).show()
            Log.e("CropCalc", "Failed to export PDF to custom location", e)
        }
    }

    private fun openFileInFileManager(file: File, mimeType: String) {
        try {
            val uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.provider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, mimeType)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(Intent.createChooser(intent, "Open with"))
            } else {
                Toast.makeText(this, "No app found to open this file. You can find it in your Downloads folder.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open this file: ${e.message}\nYou can find it in your Downloads folder.", Toast.LENGTH_LONG).show()
        }
    }

    private fun generateReportContent(): String {
        val calculation = currentCalculation!!
        val totalYield = calculation.landSize * calculation.expectedYieldPerHectare
        val totalRevenue = totalYield * calculation.sellingPricePerKg
        val totalCost = calculation.seedCost + calculation.fertilizerCost + calculation.laborCost
        val profit = totalRevenue - totalCost
        val profitMargin = if (totalRevenue > 0) (profit / totalRevenue) * 100 else 0.0
        val roi = if (totalCost > 0) (profit / totalCost) * 100 else 0.0

        return """
            CROP CALCULATION REPORT
            Generated on: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}
            
            INPUT PARAMETERS:
            - Crop Name: ${calculation.cropName}
            - Land Size: ${calculation.landSize} hectares
            - Seed Cost: ₱${calculation.seedCost}
            - Fertilizer Cost: ₱${calculation.fertilizerCost}
            - Labor Cost: ₱${calculation.laborCost}
            - Selling Price per kg: ₱${calculation.sellingPricePerKg}
            - Expected Yield per hectare: ${calculation.expectedYieldPerHectare} kg
            
            CALCULATION RESULTS:
            - Total Yield: ${String.format("%.2f", totalYield)} kg
            - Total Revenue: ₱${String.format("%.2f", totalRevenue)}
            - Total Cost: ₱${String.format("%.2f", totalCost)}
            - Profit: ₱${String.format("%.2f", profit)}
            - Profit Margin: ${String.format("%.1f", profitMargin)}%
            - ROI: ${String.format("%.1f", roi)}%
            
            RECOMMENDATION:
            ${if (profit > 0) "This crop appears profitable!" else "This crop may not be profitable. Consider adjusting parameters."}
        """.trimIndent()
    }

    private fun generateCSVContent(): String {
        val calculation = currentCalculation!!
        val totalYield = calculation.landSize * calculation.expectedYieldPerHectare
        val totalRevenue = totalYield * calculation.sellingPricePerKg
        val totalCost = calculation.seedCost + calculation.fertilizerCost + calculation.laborCost
        val profit = totalRevenue - totalCost
        val profitMargin = if (totalRevenue > 0) (profit / totalRevenue) * 100 else 0.0
        val roi = if (totalCost > 0) (profit / totalCost) * 100 else 0.0

        return """
            Parameter,Value
            Crop Name,${calculation.cropName}
            Land Size (hectares),${calculation.landSize}
            Seed Cost (₱),${calculation.seedCost}
            Fertilizer Cost (₱),${calculation.fertilizerCost}
            Labor Cost (₱),${calculation.laborCost}
            Selling Price per kg (₱),${calculation.sellingPricePerKg}
            Expected Yield per hectare (kg),${calculation.expectedYieldPerHectare}
            Total Yield (kg),${String.format("%.2f", totalYield)}
            Total Revenue (₱),${String.format("%.2f", totalRevenue)}
            Total Cost (₱),${String.format("%.2f", totalCost)}
            Profit (₱),${String.format("%.2f", profit)}
            Profit Margin (%),${String.format("%.1f", profitMargin)}
            ROI (%),${String.format("%.1f", roi)}
        """.trimIndent()
    }

    override fun onBackPressed() {
        if (calculationResultShown && lastCalculationDescription != null) {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Save Calculation")
                .setMessage("Do you want to save this calculation to your Activity Log?")
                .setPositiveButton("Save") { _, _ ->
                    saveCalculationToActivityLog(lastCalculationDescription!!)
                    val intent = Intent(this, ActivityLogActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish()
                }
                .setNegativeButton("No") { _, _ ->
                    super.onBackPressed()
                }
                .setCancelable(true)
                .show()
        } else {
            super.onBackPressed()
        }
    }

    private fun saveCalculationToActivityLog(description: String) {
        val prefs = getSharedPreferences("ActivityLogPrefs", MODE_PRIVATE)
        val logs = prefs.getStringSet("logs", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        val timestamp = System.currentTimeMillis()
        logs.add("$timestamp|CALCULATION|$description")
        prefs.edit().putStringSet("logs", logs).apply()
    }
}