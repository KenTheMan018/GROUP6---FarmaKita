package com.example.farmkita

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.farmkita.databinding.ActivitySalesPerformanceBinding
import java.text.NumberFormat
import java.util.Locale
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.widget.TextView
import com.example.farmkita.CropCalculationActivity

class SalesPerformanceActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySalesPerformanceBinding
    private val numberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalesPerformanceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupBottomNavigation()
        setupFloatingActionButton()
        updateDashboardMetrics()
        setupSalesChart()
        setupProfitableCropsList()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(false)
            title = "Analytics"
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                    true
                }
                R.id.navigation_market -> {
                    // Navigate to Market (you might need to implement this)
                    true
                }
                R.id.navigation_analytics -> {
                    // Already on analytics page
                    true
                }
                R.id.navigation_profile -> {
                    // Navigate to Profile (you might need to implement this)
                    true
                }
                else -> false
            }
        }
        
        // Set the analytics item as selected
        binding.bottomNavigation.selectedItemId = R.id.navigation_analytics
    }

    private fun setupFloatingActionButton() {
        binding.fabCalculator.setOnClickListener {
            startActivity(Intent(this, CropCalculationActivity::class.java))
        }
    }

    private fun updateDashboardMetrics() {
        // Realistic data for ordinary Filipino farmers
        binding.totalSalesValue.text = "₱" + String.format("%,.2f", 180000.0)  // Total 6 months
        binding.averageOrderValue.text = "₱" + String.format("%,.2f", 1500.0)  // Average per order
        binding.totalOrdersValue.text = "120"  // Total orders in 6 months
        binding.growthRateValue.text = "+8.2%"  // Realistic growth rate
    }

    private fun setupSalesChart() {
        val chart = binding.salesLineChart
        val entries = listOf(
            Entry(0f, 25000f), // January
            Entry(1f, 28000f), // February
            Entry(2f, 32000f), // March
            Entry(3f, 27000f), // April
            Entry(4f, 35000f), // May
            Entry(5f, 43000f)  // June
        )
        val dataSet = LineDataSet(entries, "Monthly Sales")
        dataSet.color = getColor(R.color.primary)
        dataSet.valueTextColor = getColor(android.R.color.black)
        dataSet.lineWidth = 2f
        dataSet.circleRadius = 4f
        dataSet.setCircleColor(getColor(R.color.primary))
        dataSet.setDrawFilled(true)
        dataSet.fillColor = getColor(R.color.primary)
        dataSet.mode = LineDataSet.Mode.CUBIC_BEZIER

        val lineData = LineData(dataSet)
        chart.data = lineData
        chart.description.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.granularity = 1f
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.granularity = 1f
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(
            listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun")
        )
        chart.legend.isEnabled = false
        chart.setTouchEnabled(false)
        chart.invalidate()
    }

    private fun setupProfitableCropsList() {
        val crops = listOf(
            ProfitableCrop("Tomato", 12000.0),
            ProfitableCrop("Eggplant", 9500.0),
            ProfitableCrop("Rice", 8000.0),
            ProfitableCrop("Corn", 7000.0),
            ProfitableCrop("Okra", 6000.0)
        )
        val recyclerView = binding.profitableCropsRecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ProfitableCropAdapter(crops)
    }
}

// ProfitableCrop data class
data class ProfitableCrop(val name: String, val profit: Double)

// ProfitableCropAdapter
class ProfitableCropAdapter(private val crops: List<ProfitableCrop>) : RecyclerView.Adapter<ProfitableCropAdapter.CropViewHolder>() {
    class CropViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cropName: TextView = view.findViewById(android.R.id.text1)
        val cropProfit: TextView = view.findViewById(android.R.id.text2)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CropViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return CropViewHolder(view)
    }
    override fun onBindViewHolder(holder: CropViewHolder, position: Int) {
        val crop = crops[position]
        holder.cropName.text = crop.name
        holder.cropProfit.text = "₱" + String.format("%,.2f", crop.profit)
    }
    override fun getItemCount() = crops.size
} 